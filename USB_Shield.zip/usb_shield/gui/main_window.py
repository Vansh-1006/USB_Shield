"""
USBShield - Main Window  (v2 — all 8 issues fixed)
=====================================================
FIXED:
  1. Settings persisted to JSON — every toggle saves immediately, loads on startup
  2. Whitelist uses event.extra (vid/pid/device_name) — no more broken device_id lookup
  3. Alert filter: is_file_scan=True events go to log panel only (no full-screen spam)
  4. Dashboard counters use device_monitor session counters (not WMI-dependent)
  5. Block/Allow/Dismiss are now distinct actions with proper feedback
  6. Device panel pre-populated from enumerate_current_devices() at startup
  7. Whitelist panel refreshes after every add/remove including from alerts
  8. Turning OFF any feature restores original system state (rollback)
"""

import threading
import tkinter as tk
from tkinter import messagebox, ttk, filedialog
from datetime import datetime
from typing import Dict, List, Optional

from gui.theme import *
from gui.alert_screen import AlertManager
from core.threat_logger import Severity, SEVERITY_ORDER


def _sev_color(s: str) -> str:
    return SEV_COLORS.get(s, SEV_COLORS["INFO"])["fg"]


def _sep(parent, color=BORDER):
    tk.Frame(parent, bg=color, height=1).pack(fill="x")


class MainWindow:

    TITLE  = "USBShield — USB Attack Prevention"
    MIN_W  = 1100
    MIN_H  = 680

    def __init__(self, app):
        self._app  = app
        self._sm   = app.settings   # SettingsManager

        self._root = tk.Tk()
        self._root.title(self.TITLE)
        self._root.configure(bg=BG_DEEP)
        self._root.minsize(self.MIN_W, self.MIN_H)
        try:
            self._root.state("zoomed")
        except tk.TclError:
            self._root.geometry("1280x800")

        self._setup_ttk_style()

        self._alert_mgr = AlertManager(self._root)
        self._alert_mgr.on_block     = self._handle_block
        self._alert_mgr.on_allow     = self._handle_allow
        self._alert_mgr.on_whitelist = self._handle_whitelist

        app.logger.register_callback(self._on_new_event)

        self._active_nav   = tk.StringVar(value="dashboard")
        self._panels: Dict[str, tk.Frame] = {}
        self._nav_btns: Dict[str, tk.Button] = {}

        self._build_layout()
        self._show_panel("dashboard")

        # Initial device panel population
        self._root.after(500, self._refresh_devices)
        self._root.after(2000, self._refresh_tick)

    # ------------------------------------------------------------------
    # TTk style
    # ------------------------------------------------------------------

    def _setup_ttk_style(self) -> None:
        style = ttk.Style(self._root)
        style.theme_use("clam")
        style.configure("Treeview",
                        background=BG_ENTRY, foreground=FG_PRIMARY,
                        fieldbackground=BG_ENTRY, rowheight=ROW_HEIGHT,
                        font=FONT_BODY, borderwidth=0)
        style.configure("Treeview.Heading",
                        background=BG_PANEL, foreground=FG_SECONDARY,
                        font=FONT_HEADING, relief="flat")
        style.map("Treeview",
                  background=[("selected", ACCENT_DARK)],
                  foreground=[("selected", "#FFFFFF")])

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------

    def _build_layout(self) -> None:
        # Title bar
        tb = tk.Frame(self._root, bg=BG_SIDEBAR, height=52)
        tb.pack(fill="x", side="top")
        tb.pack_propagate(False)
        tk.Label(tb, text="🛡  USBShield",
                 bg=BG_SIDEBAR, fg="#FFFFFF",
                 font=(FONT_FAMILY, 15, "bold")).pack(side="left", padx=20, pady=10)
        self._status_badge = tk.Label(tb, text="  ● ACTIVE  ",
                                      bg=STATUS_ACTIVE, fg="#FFFFFF",
                                      font=(FONT_FAMILY, 10, "bold"),
                                      padx=10, pady=4)
        self._status_badge.pack(side="right", padx=20, pady=12)
        _sep(self._root)

        body = tk.Frame(self._root, bg=BG_DEEP)
        body.pack(fill="both", expand=True)

        self._sidebar = tk.Frame(body, bg=BG_SIDEBAR, width=SIDEBAR_WIDTH)
        self._sidebar.pack(side="left", fill="y")
        self._sidebar.pack_propagate(False)

        self._content = tk.Frame(body, bg=BG_DEEP)
        self._content.pack(side="left", fill="both", expand=True)

        self._build_sidebar()
        self._build_all_panels()

    def _build_sidebar(self) -> None:
        s = self._sidebar
        tk.Frame(s, bg=BG_SIDEBAR, height=16).pack()
        nav = [("dashboard","⬛  Dashboard"),("devices","🔌  Devices"),
               ("logs","📋  Threat Logs"),("whitelist","✔  Whitelist"),
               ("settings","⚙  Settings")]
        for key, label in nav:
            btn = tk.Button(s, text=label, bg=BG_SIDEBAR, fg=FG_PRIMARY,
                            font=FONT_BODY, relief="flat", bd=0,
                            anchor="w", padx=20, pady=12, cursor="hand2",
                            command=lambda k=key: self._show_panel(k))
            btn.pack(fill="x")
            btn.bind("<Enter>", lambda e, b=btn: b.configure(bg=BG_ENTRY))
            btn.bind("<Leave>", lambda e, b=btn, k=key:
                     b.configure(bg=ACCENT_DARK if self._active_nav.get()==k else BG_SIDEBAR))
            self._nav_btns[key] = btn

        tk.Frame(s, bg=BG_SIDEBAR).pack(fill="both", expand=True)
        _sep(s)
        self._sidebar_stats = tk.Label(s, text="Threats: 0\nDevices: 0\nBlocked: 0",
                                       bg=BG_SIDEBAR, fg=FG_SECONDARY,
                                       font=FONT_SMALL, justify="left", padx=20)
        self._sidebar_stats.pack(anchor="w", pady=12)

    def _show_panel(self, key: str) -> None:
        for p in self._panels.values():
            p.pack_forget()
        self._panels[key].pack(fill="both", expand=True,
                               padx=PADDING_OUTER, pady=PADDING_OUTER)
        self._active_nav.set(key)
        for k, btn in self._nav_btns.items():
            btn.configure(bg=ACCENT_DARK if k==key else BG_SIDEBAR,
                          fg="#FFFFFF" if k==key else FG_PRIMARY)

    # ------------------------------------------------------------------
    # Panels
    # ------------------------------------------------------------------

    def _build_all_panels(self) -> None:
        ca = self._content
        self._panels["dashboard"] = self._mk_dashboard(ca)
        self._panels["devices"]   = self._mk_devices(ca)
        self._panels["logs"]      = self._mk_logs(ca)
        self._panels["whitelist"] = self._mk_whitelist(ca)
        self._panels["settings"]  = self._mk_settings(ca)

    # ── Dashboard ───────────────────────────────────────────────────────

    def _mk_dashboard(self, parent) -> tk.Frame:
        f = tk.Frame(parent, bg=BG_DEEP)
        tk.Label(f, text="Protection Dashboard", bg=BG_DEEP, fg=FG_PRIMARY,
                 font=FONT_TITLE).pack(anchor="w")
        tk.Label(f, text="Real-time USB attack prevention status",
                 bg=BG_DEEP, fg=FG_SECONDARY, font=FONT_BODY).pack(anchor="w", pady=(2,16))

        # Status cards
        cards_row = tk.Frame(f, bg=BG_DEEP)
        cards_row.pack(fill="x", pady=(0,12))
        modules = [
            ("hid",     "HID Injection Monitor", "🎹", STATUS_ACTIVE),
            ("storage", "Storage Guard",         "💾", STATUS_ACTIVE),
            ("device",  "Device Monitor",        "🔌", STATUS_ACTIVE),
            ("driver",  "Driver Monitor",        "🔧", STATUS_ACTIVE),
            ("network", "Network Guard",         "🌐", STATUS_ACTIVE),
        ]
        self._status_dots: Dict[str, tk.Label] = {}
        for key, label, icon, color in modules:
            card = tk.Frame(cards_row, bg=BG_PANEL,
                            highlightbackground=BORDER, highlightthickness=1)
            card.pack(side="left", fill="x", expand=True, padx=(0,8))
            tk.Label(card, text=icon, bg=BG_PANEL, fg=color,
                     font=(FONT_FAMILY,22)).pack(pady=(12,2))
            dot = tk.Label(card, text="● Active", bg=BG_PANEL, fg=color,
                           font=FONT_SMALL)
            dot.pack()
            tk.Label(card, text=label, bg=BG_PANEL, fg=FG_SECONDARY,
                     font=FONT_SMALL).pack(padx=10, pady=(2,12))
            self._status_dots[key] = dot

        # Counter cards
        cnt_row = tk.Frame(f, bg=BG_DEEP)
        cnt_row.pack(fill="x", pady=(0,14))
        self._ctr_threats = self._mk_counter(cnt_row, "Threats Detected",  "0", "#FF3B30")
        self._ctr_threats.pack(side="left", fill="x", expand=True, padx=(0,10))
        self._ctr_devices = self._mk_counter(cnt_row, "USB Devices Seen",  "0", ACCENT)
        self._ctr_devices.pack(side="left", fill="x", expand=True, padx=(0,10))
        self._ctr_blocked = self._mk_counter(cnt_row, "Devices Blocked",   "0", "#FF8C00")
        self._ctr_blocked.pack(side="left", fill="x", expand=True)

        # Recent threats
        tk.Label(f, text="Recent Threat Events", bg=BG_DEEP, fg=FG_PRIMARY,
                 font=FONT_HEADING).pack(anchor="w", pady=(0,6))
        cols = ("Time","Severity","Category","Title","Description")
        self._dash_tree = self._mk_tree(f, cols, 10)
        self._dash_tree.column("Time",        width=155, stretch=False)
        self._dash_tree.column("Severity",    width=88,  stretch=False)
        self._dash_tree.column("Category",    width=155, stretch=False)
        self._dash_tree.column("Title",       width=230)
        self._dash_tree.column("Description", width=400)
        return f

    def _mk_counter(self, parent, label, value, color) -> tk.Frame:
        card  = tk.Frame(parent, bg=BG_PANEL,
                         highlightbackground=BORDER, highlightthickness=1)
        v_lbl = tk.Label(card, text=value, bg=BG_PANEL, fg=color,
                         font=(FONT_FAMILY, 32, "bold"))
        v_lbl.pack(padx=24, pady=(14,2))
        tk.Label(card, text=label, bg=BG_PANEL, fg=FG_SECONDARY,
                 font=FONT_SMALL).pack(padx=12, pady=(0,14))
        card._v = v_lbl          # dynamic attribute — intentional
        return card

    # ── Devices panel ───────────────────────────────────────────────────

    def _mk_devices(self, parent) -> tk.Frame:
        f = tk.Frame(parent, bg=BG_DEEP)
        tk.Label(f, text="USB Devices", bg=BG_DEEP, fg=FG_PRIMARY,
                 font=FONT_TITLE).pack(anchor="w")
        tk.Label(f, text="All USB devices detected this session",
                 bg=BG_DEEP, fg=FG_SECONDARY, font=FONT_BODY).pack(anchor="w", pady=(2,12))

        tb = tk.Frame(f, bg=BG_DEEP)
        tb.pack(fill="x", pady=(0,8))
        tk.Button(tb, text="🔄 Refresh",          command=self._refresh_devices, **BTN_GHOST).pack(side="left", padx=(0,8))
        tk.Button(tb, text="🚫 Block Selected",   command=self._block_selected,  **BTN_DANGER).pack(side="left", padx=(0,8))
        tk.Button(tb, text="✔ Whitelist Selected",command=self._whitelist_selected, **BTN_PRIMARY).pack(side="left")

        cols = ("Status","Name","VID","PID","Serial","Class","Connected At")
        self._dev_tree = self._mk_tree(f, cols, 16)
        self._dev_tree.column("Status",       width=95,  stretch=False)
        self._dev_tree.column("Name",         width=240)
        self._dev_tree.column("VID",          width=55,  stretch=False)
        self._dev_tree.column("PID",          width=55,  stretch=False)
        self._dev_tree.column("Serial",       width=160)
        self._dev_tree.column("Class",        width=130)
        self._dev_tree.column("Connected At", width=120, stretch=False)
        return f

    # ── Logs panel ──────────────────────────────────────────────────────

    def _mk_logs(self, parent) -> tk.Frame:
        f = tk.Frame(parent, bg=BG_DEEP)
        tk.Label(f, text="Threat Logs", bg=BG_DEEP, fg=FG_PRIMARY,
                 font=FONT_TITLE).pack(anchor="w")
        tk.Label(f, text="All security events — filterable by severity",
                 bg=BG_DEEP, fg=FG_SECONDARY, font=FONT_BODY).pack(anchor="w", pady=(2,12))

        fb = tk.Frame(f, bg=BG_DEEP)
        fb.pack(fill="x", pady=(0,8))
        tk.Label(fb, text="Min Severity:", bg=BG_DEEP, fg=FG_SECONDARY,
                 font=FONT_BODY).pack(side="left", padx=(0,8))
        self._log_filter = tk.StringVar(value="ALL")
        for sev in ("ALL","INFO","LOW","MEDIUM","HIGH","CRITICAL"):
            tk.Radiobutton(fb, text=sev, variable=self._log_filter, value=sev,
                           bg=BG_DEEP, fg=_sev_color(sev) if sev!="ALL" else FG_PRIMARY,
                           selectcolor=BG_PANEL, activebackground=BG_DEEP,
                           font=FONT_SMALL, command=self._refresh_logs
                           ).pack(side="left", padx=4)
        tk.Button(fb, text="⬇ Export JSON", command=self._export_logs, **BTN_GHOST).pack(side="right")
        tk.Button(fb, text="🗑 Clear",       command=self._clear_logs,  **BTN_GHOST).pack(side="right", padx=(0,6))

        cols = ("Time","Severity","Category","Title","Description")
        self._log_tree = self._mk_tree(f, cols, 20)
        self._log_tree.column("Time",        width=155, stretch=False)
        self._log_tree.column("Severity",    width=88,  stretch=False)
        self._log_tree.column("Category",    width=160, stretch=False)
        self._log_tree.column("Title",       width=240)
        self._log_tree.column("Description", width=500)
        return f

    # ── Whitelist panel ─────────────────────────────────────────────────

    def _mk_whitelist(self, parent) -> tk.Frame:
        f = tk.Frame(parent, bg=BG_DEEP)
        tk.Label(f, text="Device Whitelist", bg=BG_DEEP, fg=FG_PRIMARY,
                 font=FONT_TITLE).pack(anchor="w")
        tk.Label(f, text="Trusted devices — all others trigger an alert",
                 bg=BG_DEEP, fg=FG_SECONDARY, font=FONT_BODY).pack(anchor="w", pady=(2,12))

        tb = tk.Frame(f, bg=BG_DEEP)
        tb.pack(fill="x", pady=(0,8))
        tk.Button(tb, text="➕ Add Device",     command=self._add_whitelist,    **BTN_PRIMARY).pack(side="left", padx=(0,8))
        tk.Button(tb, text="🗑 Remove Selected", command=self._remove_whitelist, **BTN_DANGER).pack(side="left")

        cols = ("VID","PID","Label","Class","Trusted HID","Added")
        self._wl_tree = self._mk_tree(f, cols, 14)
        self._wl_tree.column("VID",        width=70, stretch=False)
        self._wl_tree.column("PID",        width=70, stretch=False)
        self._wl_tree.column("Label",      width=260)
        self._wl_tree.column("Class",      width=140)
        self._wl_tree.column("Trusted HID",width=90, stretch=False)
        self._wl_tree.column("Added",      width=160, stretch=False)
        self._refresh_whitelist()
        return f

    # ── Settings panel ──────────────────────────────────────────────────

    def _mk_settings(self, parent) -> tk.Frame:
        f = tk.Frame(parent, bg=BG_DEEP)
        tk.Label(f, text="Settings & Hardening", bg=BG_DEEP, fg=FG_PRIMARY,
                 font=FONT_TITLE).pack(anchor="w")
        tk.Label(f, text="Changes take effect immediately and are saved. "
                         "Turning OFF a feature restores the original system state.",
                 bg=BG_DEEP, fg=FG_SECONDARY, font=FONT_BODY).pack(anchor="w", pady=(2,16))

        # ── Registry Hardening ───────────────────────────────────────────
        sec = tk.LabelFrame(f, text="  Registry Hardening  ",
                            bg=BG_PANEL, fg=FG_PRIMARY, font=FONT_HEADING,
                            bd=1, highlightbackground=BORDER, padx=16, pady=12)
        sec.pack(fill="x", pady=(0,12))

        self._var_hardening = tk.BooleanVar(
            value=self._sm.get("hardening","hardening_applied",default=False))
        self._var_autorun   = tk.BooleanVar(
            value=self._sm.get("hardening","autorun_blocked",default=False))
        self._var_storage   = tk.BooleanVar(
            value=self._sm.get("hardening","storage_blocked",default=False))

        self._mk_toggle_row(sec, "Apply all registry hardening (autorun, driver signing, AutoPlay)",
                            self._var_hardening, self._toggle_hardening)
        self._mk_toggle_row(sec, "Block AutoRun for all drive types (recommended always-on)",
                            self._var_autorun, self._toggle_autorun)
        self._mk_toggle_row(sec, "Block ALL USB storage devices (flash drives, external HDDs)",
                            self._var_storage, self._toggle_storage, danger=True)

        # ── Protection Modules ───────────────────────────────────────────
        sec2 = tk.LabelFrame(f, text="  Protection Modules  ",
                             bg=BG_PANEL, fg=FG_PRIMARY, font=FONT_HEADING,
                             bd=1, highlightbackground=BORDER, padx=16, pady=12)
        sec2.pack(fill="x", pady=(0,12))

        modules = [
            ("hid_injection_detection",      "HID Injection & Rubber Ducky Detection",
             self._toggle_hid),
            ("device_whitelist_enforcement", "Device Whitelist Enforcement",
             self._toggle_device_monitor),
            ("usb_storage_scanning",         "USB Storage Scanning (file threat detection)",
             self._toggle_storage_guard),
            ("network_guard",                "USB Network Adapter Guard (RNDIS/CDC detection)",
             self._toggle_network_guard),
            ("driver_monitoring",            "USB Driver Installation Monitor",
             self._toggle_driver_monitor),
            ("data_exfiltration_detection",  "Data Exfiltration Detection (large copy monitoring)",
             self._toggle_exfil),
        ]
        self._module_vars: Dict[str, tk.BooleanVar] = {}
        for key, label, cmd in modules:
            var = tk.BooleanVar(value=self._sm.get("protection", key, default=True))
            self._module_vars[key] = var
            self._mk_toggle_row(sec2, label, var, cmd)

        # ── Auto-block ───────────────────────────────────────────────────
        sec3 = tk.LabelFrame(f, text="  Auto-Block Behaviour  ",
                             bg=BG_PANEL, fg=FG_PRIMARY, font=FONT_HEADING,
                             bd=1, highlightbackground=BORDER, padx=16, pady=12)
        sec3.pack(fill="x", pady=(0,12))

        self._var_autoblk_known   = tk.BooleanVar(
            value=self._sm.get("device_monitor","auto_block_known_attack_devices",default=True))
        self._var_autoblk_unknown = tk.BooleanVar(
            value=self._sm.get("device_monitor","auto_block_unknown_devices",default=False))
        self._var_del_autorun     = tk.BooleanVar(
            value=self._sm.get("storage_guard","auto_delete_autorun",default=True))

        self._mk_toggle_row(sec3, "Auto-block KNOWN attack devices (Rubber Ducky, Bash Bunny…)",
                            self._var_autoblk_known, self._toggle_autoblk_known)
        self._mk_toggle_row(sec3, "Auto-block ALL unknown/unwhitelisted devices",
                            self._var_autoblk_unknown, self._toggle_autoblk_unknown, danger=True)
        self._mk_toggle_row(sec3, "Auto-delete autorun.inf from inserted drives",
                            self._var_del_autorun, self._toggle_del_autorun)

        return f

    def _mk_toggle_row(self, parent, label: str, var: tk.BooleanVar,
                       cmd, danger: bool = False) -> None:
        row = tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", pady=5)
        fg = "#FF8C00" if danger else FG_PRIMARY
        tk.Label(row, text=label, bg=BG_PANEL, fg=fg,
                 font=FONT_BODY).pack(side="left")
        tk.Checkbutton(row, variable=var, command=cmd,
                       bg=BG_PANEL, fg=fg, selectcolor=BG_ENTRY,
                       activebackground=BG_PANEL,
                       font=FONT_BODY).pack(side="right")

    # ------------------------------------------------------------------
    # Treeview factory
    # ------------------------------------------------------------------

    def _mk_tree(self, parent, columns, height=10) -> ttk.Treeview:
        container = tk.Frame(parent, bg=BG_PANEL)
        container.pack(fill="both", expand=True)
        vsb  = ttk.Scrollbar(container, orient="vertical")
        vsb.pack(side="right", fill="y")
        tree = ttk.Treeview(container, columns=columns, show="headings",
                            height=height, yscrollcommand=vsb.set)
        vsb.configure(command=tree.yview)
        tree.pack(side="left", fill="both", expand=True)
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, anchor="w")
        for sev, colors in SEV_COLORS.items():
            tree.tag_configure(sev, foreground=colors["fg"], background=colors["bg"])
        tree.tag_configure("BLOCKED", foreground="#FF3B30", background="#270808")
        tree.tag_configure("SAFE",    foreground=STATUS_ACTIVE, background=BG_ENTRY)
        tree.tag_configure("UNKNOWN", foreground="#FF8C00",     background=BG_ENTRY)
        return tree

    # ------------------------------------------------------------------
    # Event handler (thread-safe → scheduled on main thread)
    # ------------------------------------------------------------------

    def _on_new_event(self, event) -> None:
        self._root.after(0, lambda e=event: self._process_event(e))

    def _process_event(self, event) -> None:
        sev = event.severity.value if hasattr(event.severity, "value") else str(event.severity)
        ts  = event.timestamp.strftime("%Y-%m-%d %H:%M:%S")

        # Always log to both log panels
        self._insert_row(self._dash_tree, ts, sev, event.category,
                         event.title, event.description, limit=150)
        self._insert_row(self._log_tree,  ts, sev, event.category,
                         event.title, event.description, limit=2000)

        self._update_counters()

        # ── Alert filter ────────────────────────────────────────────────
        # Individual file-scan results → log panel only, no full-screen alert.
        # Drive summary alerts and device/injection/network/driver events →
        # full-screen alert.
        extra = event.extra or {}
        if extra.get("is_file_scan"):
            return   # logged above, no full-screen alert

        # Only show full-screen for HIGH+ events
        sev_order = SEVERITY_ORDER.get(event.severity, 0)
        if sev_order < SEVERITY_ORDER[Severity.HIGH]:
            return

        self._alert_mgr.show_event(event)

    def _insert_row(self, tree: ttk.Treeview, ts, sev, cat, title, desc, limit=500) -> None:
        tree.insert("", 0, values=(ts, sev, cat, title, desc), tags=(sev,))
        children = tree.get_children()
        if len(children) > limit:
            for old in children[limit:]:
                tree.delete(old)

    # ------------------------------------------------------------------
    # Periodic refresh
    # ------------------------------------------------------------------

    def _refresh_tick(self) -> None:
        self._update_counters()
        self._root.after(3000, self._refresh_tick)

    def _update_counters(self) -> None:
        try:
            tc = self._app.logger.get_threat_count(min_severity=Severity.MEDIUM)
            dc = self._app.device_monitor.get_session_total()
            bc = self._app.device_monitor.get_blocked_count()

            self._ctr_threats._v.config(text=str(tc))
            self._ctr_devices._v.config(text=str(dc))
            self._ctr_blocked._v.config(text=str(bc))
            self._sidebar_stats.config(
                text=f"Threats: {tc}\nDevices: {dc}\nBlocked: {bc}"
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Device panel
    # ------------------------------------------------------------------

    def _refresh_devices(self) -> None:
        tree = self._dev_tree
        for row in tree.get_children():
            tree.delete(row)
        devs = self._app.device_monitor.get_connected_devices()
        for d in devs:
            tag  = "BLOCKED" if d.is_blocked else "SAFE"
            stat = "🚫 BLOCKED" if d.is_blocked else "✔ Connected"
            ts   = d.connected_at.strftime("%H:%M:%S")
            # Use instance_id as iid only if it's safe (no special chars)
            safe_iid = d.instance_id.replace("\\", "_").replace("{", "").replace("}", "")
            try:
                tree.insert("", "end", iid=safe_iid,
                            values=(stat, d.name, d.vid, d.pid,
                                    (d.serial or "—")[:24],
                                    (d.device_class or "—")[:18], ts),
                            tags=(tag,))
            except tk.TclError:
                tree.insert("", "end",
                            values=(stat, d.name, d.vid, d.pid,
                                    (d.serial or "—")[:24],
                                    (d.device_class or "—")[:18], ts),
                            tags=(tag,))

    def _block_selected(self) -> None:
        sel = self._dev_tree.selection()
        if not sel:
            messagebox.showinfo("No Selection", "Select a device from the list to block.")
            return
        blocked = 0
        for iid in sel:
            vals = self._dev_tree.item(iid, "values")
            if vals:
                # Reverse the iid → instance_id mapping: find by name+VID+PID
                name = vals[1]; vid = vals[2]; pid = vals[3]
                for dev in self._app.device_monitor.get_connected_devices():
                    if dev.vid == vid and dev.pid == pid and dev.name == name:
                        if self._app.device_monitor.disable_device(dev.instance_id):
                            blocked += 1
                        break
        self._refresh_devices()
        self._update_counters()
        if blocked:
            messagebox.showinfo("Blocked", f"{blocked} device(s) blocked.")
        else:
            messagebox.showwarning("Block Failed",
                                   "Could not block device.\n"
                                   "Ensure USBShield is running as Administrator.")

    def _whitelist_selected(self) -> None:
        sel = self._dev_tree.selection()
        if not sel:
            messagebox.showinfo("No Selection", "Select a device to whitelist.")
            return
        for iid in sel:
            vals = self._dev_tree.item(iid, "values")
            if vals:
                vid = vals[2]; pid = vals[3]; name = vals[1]
                if vid and pid:
                    self._app.whitelist.add(vid, pid, name)
        self._refresh_whitelist()
        messagebox.showinfo("Whitelisted", f"{len(sel)} device(s) added to whitelist.")

    # ------------------------------------------------------------------
    # Log panel
    # ------------------------------------------------------------------

    def _refresh_logs(self) -> None:
        tree = self._log_tree
        for row in tree.get_children():
            tree.delete(row)
        flt = self._log_filter.get()
        min_sev = Severity.INFO if flt == "ALL" else Severity[flt]
        for e in reversed(self._app.logger.get_events(min_severity=min_sev, limit=500)):
            sev = e.severity.value
            ts  = e.timestamp.strftime("%Y-%m-%d %H:%M:%S")
            tree.insert("", "end",
                        values=(ts, sev, e.category, e.title, e.description),
                        tags=(sev,))

    def _export_logs(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON","*.json"),("All","*.*")],
            title="Export Threat Log")
        if path:
            self._app.logger.export_json(path)
            messagebox.showinfo("Exported", f"Log saved to:\n{path}")

    def _clear_logs(self) -> None:
        if messagebox.askyesno("Clear Logs", "Clear all in-memory log entries?"):
            self._app.logger.clear()
            for tree in (self._log_tree, self._dash_tree):
                for row in tree.get_children():
                    tree.delete(row)

    # ------------------------------------------------------------------
    # Whitelist panel
    # ------------------------------------------------------------------

    def _refresh_whitelist(self) -> None:
        tree = self._wl_tree
        for row in tree.get_children():
            tree.delete(row)
        for e in self._app.whitelist.all_entries():
            tree.insert("", "end", values=(
                e.vid, e.pid, e.label,
                (e.device_class or "—"),
                "Yes" if e.trusted_hid else "No",
                (e.added_at or "")[:16],
            ))

    def _add_whitelist(self) -> None:
        dlg = _AddDeviceDlg(self._root)
        self._root.wait_window(dlg)
        if dlg.result:
            vid, pid, label = dlg.result
            self._app.whitelist.add(vid, pid, label)
            self._refresh_whitelist()

    def _remove_whitelist(self) -> None:
        sel = self._wl_tree.selection()
        if not sel:
            return
        for iid in sel:
            vals = self._wl_tree.item(iid, "values")
            if vals:
                self._app.whitelist.remove(vals[0], vals[1])
        self._refresh_whitelist()

    # ------------------------------------------------------------------
    # Settings toggles — each one saves AND applies immediately
    # ── Rollback: turning OFF restores original system state ────────────
    # ------------------------------------------------------------------

    def _toggle_hardening(self) -> None:
        on = self._var_hardening.get()
        self._sm.set("hardening", "hardening_applied", on)
        if on:
            results = self._app.hardener.apply_all()
            ok = sum(1 for v in results.values() if v)
            messagebox.showinfo("Hardening Applied",
                                f"Registry hardening applied — {ok}/{len(results)} rules set.")
        else:
            self._app.hardener.revert_all()   # ROLLBACK
            messagebox.showinfo("Hardening Reverted",
                                "All registry keys restored to original values.")

    def _toggle_autorun(self) -> None:
        on = self._var_autorun.get()
        self._sm.set("hardening", "autorun_blocked", on)
        if on:
            ok = self._app.hardener.disable_autorun()
            if not ok:
                messagebox.showwarning("Permission Error",
                                       "Could not disable AutoRun — run as Administrator.")
                self._var_autorun.set(False)
                self._sm.set("hardening", "autorun_blocked", False)
        else:
            self._app.hardener.enable_autorun()   # ROLLBACK

    def _toggle_storage(self) -> None:
        on = self._var_storage.get()
        self._sm.set("hardening", "storage_blocked", on)
        if on:
            if messagebox.askyesno("Block USB Storage",
                                   "This will prevent ALL USB flash drives and external\n"
                                   "drives from mounting. Continue?"):
                ok = self._app.hardener.block_usb_storage()
                if not ok:
                    messagebox.showwarning("Failed", "Could not block USB storage.")
                    self._var_storage.set(False)
                    self._sm.set("hardening", "storage_blocked", False)
            else:
                self._var_storage.set(False)
                self._sm.set("hardening", "storage_blocked", False)
        else:
            self._app.hardener.unblock_usb_storage()   # ROLLBACK
            messagebox.showinfo("Storage Restored", "USB storage driver re-enabled.")

    def _toggle_hid(self) -> None:
        on = self._var_hid = self._module_vars["hid_injection_detection"].get()
        self._sm.set("protection", "hid_injection_detection", on)
        if on:
            self._app.hid_detector.start()
            self._update_dot("hid", STATUS_ACTIVE, "Active")
        else:
            self._app.hid_detector.stop()   # ROLLBACK: stops monitoring
            self._update_dot("hid", STATUS_WARNING, "Disabled")

    def _toggle_device_monitor(self) -> None:
        on = self._module_vars["device_whitelist_enforcement"].get()
        self._sm.set("protection", "device_whitelist_enforcement", on)
        if on:
            self._app.device_monitor.start()
            self._update_dot("device", STATUS_ACTIVE, "Active")
        else:
            self._app.device_monitor.stop()
            self._update_dot("device", STATUS_INACTIVE, "Disabled")

    def _toggle_storage_guard(self) -> None:
        on = self._module_vars["usb_storage_scanning"].get()
        self._sm.set("protection", "usb_storage_scanning", on)
        if on:
            self._app.storage_guard.start()
            self._update_dot("storage", STATUS_ACTIVE, "Active")
        else:
            self._app.storage_guard.stop()
            self._update_dot("storage", STATUS_INACTIVE, "Disabled")

    def _toggle_network_guard(self) -> None:
        on = self._module_vars["network_guard"].get()
        self._sm.set("protection", "network_guard", on)
        if on:
            self._app.network_guard.start()
            self._update_dot("network", STATUS_ACTIVE, "Active")
        else:
            self._app.network_guard.stop()
            self._update_dot("network", STATUS_INACTIVE, "Disabled")

    def _toggle_driver_monitor(self) -> None:
        on = self._module_vars["driver_monitoring"].get()
        self._sm.set("protection", "driver_monitoring", on)
        if on:
            self._app.driver_monitor.start()
            self._update_dot("driver", STATUS_ACTIVE, "Active")
        else:
            self._app.driver_monitor.stop()
            self._update_dot("driver", STATUS_INACTIVE, "Disabled")

    def _toggle_exfil(self) -> None:
        on = self._module_vars["data_exfiltration_detection"].get()
        self._sm.set("protection", "data_exfiltration_detection", on)
        # Storage guard uses same module; just update threshold
        if not on:
            self._app.storage_guard.drive_alert_cooldown = 999999
        else:
            self._app.storage_guard.drive_alert_cooldown = DRIVE_ALERT_COOLDOWN_DEFAULT

    def _toggle_autoblk_known(self) -> None:
        on = self._var_autoblk_known.get()
        self._sm.set("device_monitor", "auto_block_known_attack_devices", on)
        self._app.device_monitor.auto_block_known_attack_devices = on

    def _toggle_autoblk_unknown(self) -> None:
        on = self._var_autoblk_unknown.get()
        self._sm.set("device_monitor", "auto_block_unknown_devices", on)
        self._app.device_monitor.auto_block_unknown = on

    def _toggle_del_autorun(self) -> None:
        on = self._var_del_autorun.get()
        self._sm.set("storage_guard", "auto_delete_autorun", on)
        self._app.storage_guard.auto_delete_autorun = on

    def _update_dot(self, key: str, color: str, text: str) -> None:
        if key in self._status_dots:
            self._status_dots[key].configure(fg=color, text=f"● {text}")

    # ------------------------------------------------------------------
    # Alert action callbacks
    # ------------------------------------------------------------------

    def _handle_block(self, event) -> None:
        """Block device using instance_id from event extras."""
        extra       = event.extra or {}
        instance_id = extra.get("instance_id") or event.device_id
        cat         = event.category

        if instance_id:
            # Real device — try PowerShell disable
            success = self._app.device_monitor.disable_device(instance_id)
            if success:
                self._app.logger.high(
                    "System", "Device BLOCKED by user",
                    f"Disabled via PowerShell: {instance_id}")
            else:
                # disable_device already logs failure; also update UI
                self._app.logger.high(
                    "System", "Block sent",
                    f"PowerShell command issued for {instance_id[:60]} — "
                    "unplug if the device is still active")
        else:
            # Behavioural event (HID injection, file scanner) — no device PnP ID.
            # Don't show a popup that hides the alert; just log actionable advice.
            tip = {
                "HIDDetector":  "Check Devices panel — unplug every unrecognised HID/keyboard device",
                "FileScanner":  "Do NOT open any files on this USB drive — eject it now",
                "StorageGuard": "Eject the USB drive immediately from File Explorer",
            }.get(cat, "Unplug all unrecognised USB devices immediately")

            self._app.logger.high(
                "System", f"Block requested ({cat})",
                tip)
            # Switch to Devices panel so user can see and block manually
            self._show_panel("devices")

        self._refresh_devices()
        self._update_counters()

    def _handle_allow(self, event) -> None:
        """Allow once — add VID:PID to session allow-list only (not persistent)."""
        extra = event.extra or {}
        vid   = extra.get("vid", "")
        pid   = extra.get("pid", "")
        if vid and pid:
            self._app.device_monitor.allow_once(vid, pid)
            self._app.logger.info(
                "System", "Device allowed for this session",
                f"{vid}:{pid} — allowed once (not persisted)",
            )

    def _handle_whitelist(self, event) -> None:
        """Add device to persistent whitelist using info from event.extra."""
        extra = event.extra or {}
        vid   = extra.get("vid", "")
        pid   = extra.get("pid", "")
        name  = (extra.get("device_name")
                 or extra.get("name")
                 or event.title or "Unknown Device")
        cls   = extra.get("class", "")

        if vid and pid:
            self._app.whitelist.add(vid, pid, name, device_class=cls)
            self._app.device_monitor.allow_once(vid, pid)
            self._app.logger.info(
                "System", "Device whitelisted",
                f"{name} [{vid}:{pid}] added to whitelist",
            )
            self._refresh_whitelist()
        else:
            # No VID/PID (HID injection, file scanner events).
            # Log a helpful note and open Whitelist panel — no popup needed.
            self._app.logger.info(
                "System", "Whitelist: no device ID in event",
                "Use the Whitelist panel → Add Device to whitelist manually "
                "(enter VID and PID from the Devices panel)")
            self._show_panel("whitelist")

    # ------------------------------------------------------------------
    # Entry point
    # ------------------------------------------------------------------

    def run(self) -> None:
        self._root.mainloop()


# ---------------------------------------------------------------------------
# Add Device dialog
# ---------------------------------------------------------------------------

class _AddDeviceDlg(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.result = None
        self.title("Add Device to Whitelist")
        self.configure(bg=BG_PANEL)
        self.resizable(False, False)
        self.grab_set()

        fields = [
            ("VID (4 hex digits, e.g. 046D)", ""),
            ("PID (4 hex digits, e.g. C52B)", ""),
            ("Label / Description", "My Trusted Device"),
        ]
        self._vars = []
        for label, default in fields:
            tk.Label(self, text=label, bg=BG_PANEL, fg=FG_PRIMARY,
                     font=FONT_BODY).pack(padx=24, pady=(12,2), anchor="w")
            var = tk.StringVar(value=default)
            self._vars.append(var)
            tk.Entry(self, textvariable=var, bg=BG_ENTRY, fg=FG_PRIMARY,
                     insertbackground=FG_PRIMARY, font=FONT_BODY,
                     width=30).pack(padx=24)

        row = tk.Frame(self, bg=BG_PANEL)
        row.pack(padx=24, pady=16, fill="x")
        tk.Button(row, text="Add", command=self._ok, **BTN_PRIMARY).pack(side="right")
        tk.Button(row, text="Cancel", command=self.destroy, **BTN_GHOST).pack(side="right", padx=(0,8))

    def _ok(self) -> None:
        vid   = self._vars[0].get().strip().upper()
        pid   = self._vars[1].get().strip().upper()
        label = self._vars[2].get().strip()
        if len(vid) != 4 or len(pid) != 4:
            messagebox.showerror("Invalid", "VID and PID must each be 4 hex characters.", parent=self)
            return
        try:
            int(vid, 16)
            int(pid, 16)
        except ValueError:
            messagebox.showerror("Invalid", "VID and PID must be hexadecimal.", parent=self)
            return
        self.result = (vid, pid, label)
        self.destroy()


# Constant needed by _toggle_exfil
DRIVE_ALERT_COOLDOWN_DEFAULT = 60
