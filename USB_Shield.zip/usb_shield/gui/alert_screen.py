"""
USBShield - Full-Screen Alert System
======================================
Delivers an unmistakable full-screen visual warning when a USB attack
is detected, with:

  • Pulsing red/dark-red background animation
  • Severity-coded color palette  (CRITICAL / HIGH / MEDIUM)
  • Large threat icon + title
  • Structured threat info: attack type, description, device, action taken
  • Action buttons: Block Device | Allow Once | Whitelist | Dismiss
  • Auto-dismiss countdown for MEDIUM (30 s) and HIGH (60 s)
  • No auto-dismiss for CRITICAL — user must act
  • Optional beep alert (Windows Beep API)
"""

import threading
import time
import tkinter as tk
from tkinter import font as tkfont
from typing import Callable, Optional

from gui.theme import ALERT_PALETTES, FONT_FAMILY


# ---------------------------------------------------------------------------
# Helper — safe beep
# ---------------------------------------------------------------------------

def _beep(frequency: int = 1000, duration_ms: int = 300) -> None:
    """Non-blocking Windows console beep. Silently ignored on non-Windows."""
    try:
        import ctypes
        ctypes.windll.kernel32.Beep(frequency, duration_ms)
    except Exception:
        pass


def _beep_async(freq=1000, dur=300):
    threading.Thread(target=_beep, args=(freq, dur), daemon=True).start()


# ---------------------------------------------------------------------------
# FullScreenAlert
# ---------------------------------------------------------------------------

class FullScreenAlert(tk.Toplevel):
    """
    Full-screen security alert overlay window.

    Parameters
    ----------
    parent        : tk root window
    event         : ThreatEvent (from core.threat_logger)
    on_block      : callback(event) — user clicked "Block Device"
    on_allow      : callback(event) — user clicked "Allow Once"
    on_whitelist  : callback(event) — user clicked "Whitelist"
    on_dismiss    : callback(event) — alert closed (any reason)
    """

    PULSE_INTERVAL_MS    = 600   # ms between background color pulses
    TITLE_BLINK_MS       = 400   # ms between title blink states
    MEDIUM_AUTO_DISMISS  = 30    # seconds
    HIGH_AUTO_DISMISS    = 60    # seconds

    def __init__(
        self,
        parent,
        event,
        on_block:     Optional[Callable] = None,
        on_allow:     Optional[Callable] = None,
        on_whitelist: Optional[Callable] = None,
        on_dismiss:   Optional[Callable] = None,
    ):
        super().__init__(parent)
        self._event      = event
        self._on_block     = on_block
        self._on_allow     = on_allow
        self._on_whitelist = on_whitelist
        self._on_dismiss   = on_dismiss

        self._severity = getattr(event, "severity", None)
        sev_str = self._severity.value if self._severity else "HIGH"
        # Map to one of our three palette keys
        palette_key = sev_str if sev_str in ALERT_PALETTES else "HIGH"
        self._pal = ALERT_PALETTES[palette_key]

        self._pulse_state  = False
        self._blink_state  = False
        self._dismissed    = False
        self._countdown    = self._auto_dismiss_seconds(sev_str)
        self._countdown_remaining = self._countdown

        self._setup_window()
        self._build_ui()
        self._start_animations()
        self._play_alert_sound(sev_str)

    # ------------------------------------------------------------------
    # Window setup
    # ------------------------------------------------------------------

    def _setup_window(self) -> None:
        # Remove window decorations and go truly full-screen
        self.overrideredirect(True)
        self.attributes("-topmost", True)

        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.geometry(f"{sw}x{sh}+0+0")

        self.configure(bg=self._pal["bg_base"])
        self.focus_force()

        # ESC = dismiss (only for non-critical)
        self.bind("<Escape>", lambda e: self._dismiss())

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        pal = self._pal
        sw  = self.winfo_screenwidth()

        # ── Top stripe ──────────────────────────────────────────────────
        top_stripe = tk.Frame(self, bg=pal["header_bg"], height=8)
        top_stripe.pack(fill="x", side="top")

        # ── Header band ─────────────────────────────────────────────────
        header = tk.Frame(self, bg=pal["header_bg"])
        header.pack(fill="x", padx=0, pady=0)

        # Shield logo + product name (left)
        tk.Label(
            header,
            text="🛡  USBShield",
            bg=pal["header_bg"],
            fg=pal["body_text"],
            font=(FONT_FAMILY, 13, "bold"),
        ).pack(side="left", padx=24, pady=12)

        # Severity badge (right)
        badge_frame = tk.Frame(header, bg=pal["badge_bg"], pady=4, padx=14)
        badge_frame.pack(side="right", padx=24, pady=10)
        tk.Label(
            badge_frame,
            text=f"  {pal['severity_label']}  ",
            bg=pal["badge_bg"],
            fg=pal["badge_fg"],
            font=(FONT_FAMILY, 11, "bold"),
        ).pack()

        # Timestamp
        ts = self._event.timestamp.strftime("%Y-%m-%d  %H:%M:%S")
        tk.Label(
            header,
            text=f"Detected at {ts}",
            bg=pal["header_bg"],
            fg=pal["body_text"],
            font=(FONT_FAMILY, 10, "normal"),
        ).pack(side="right", padx=16)

        # ── Main body (centered column) ──────────────────────────────────
        body = tk.Frame(self, bg=pal["bg_base"])
        body.pack(fill="both", expand=True)

        # Center column with fixed width
        center = tk.Frame(body, bg=pal["bg_base"])
        center.place(relx=0.5, rely=0.5, anchor="center")

        # Giant warning icon
        self._icon_label = tk.Label(
            center,
            text=pal["icon"],
            bg=pal["bg_base"],
            fg=pal["accent"],
            font=(FONT_FAMILY, 80),
        )
        self._icon_label.pack(pady=(0, 10))

        # Main threat title (large, blinking)
        self._title_label = tk.Label(
            center,
            text=self._event.title.upper(),
            bg=pal["bg_base"],
            fg=pal["title_color"],
            font=(FONT_FAMILY, 36, "bold"),
            wraplength=min(sw - 200, 1100),
            justify="center",
        )
        self._title_label.pack(pady=(0, 6))

        # Subtitle — attack category
        tk.Label(
            center,
            text=f"Attack Category:  {self._event.category}",
            bg=pal["bg_base"],
            fg=pal["accent2"],
            font=(FONT_FAMILY, 16, "bold"),
        ).pack(pady=(0, 20))

        # ── Info card ────────────────────────────────────────────────────
        info_card = tk.Frame(
            center,
            bg=pal["info_bg"],
            highlightbackground=pal["info_border"],
            highlightthickness=2,
            padx=30,
            pady=20,
        )
        info_card.pack(fill="x", padx=0, pady=(0, 20), ipadx=10, ipady=10)
        info_card.configure(width=min(sw - 200, 900))

        # Build info rows
        rows = self._build_info_rows()
        for label_text, value_text, value_fg in rows:
            row = tk.Frame(info_card, bg=pal["info_bg"])
            row.pack(fill="x", pady=4)

            tk.Label(
                row,
                text=f"{label_text}:",
                bg=pal["info_bg"],
                fg=pal["subtitle"],
                font=(FONT_FAMILY, 12, "bold"),
                width=22,
                anchor="e",
            ).pack(side="left", padx=(0, 12))

            tk.Label(
                row,
                text=value_text,
                bg=pal["info_bg"],
                fg=value_fg or pal["body_text"],
                font=(FONT_FAMILY, 12, "normal"),
                wraplength=min(sw - 500, 680),
                justify="left",
                anchor="w",
            ).pack(side="left", fill="x", expand=True)

        # ── Recommendation strip ─────────────────────────────────────────
        rec_frame = tk.Frame(
            center,
            bg=pal["accent"],
            padx=20,
            pady=10,
        )
        rec_frame.pack(fill="x", pady=(0, 24))
        tk.Label(
            rec_frame,
            text=f"⚑  RECOMMENDED ACTION:  {self._recommended_action()}",
            bg=pal["accent"],
            fg="#FFFFFF",
            font=(FONT_FAMILY, 13, "bold"),
        ).pack()

        # ── Action buttons ───────────────────────────────────────────────
        btn_row = tk.Frame(center, bg=pal["bg_base"])
        btn_row.pack(pady=(0, 10))

        sev_str = self._severity.value if self._severity else "HIGH"

        self._make_button(
            btn_row, "🚫  BLOCK DEVICE NOW",
            pal["btn_block"]["bg"], pal["btn_block"]["fg"],
            pal["btn_block"]["active"], self._action_block,
            large=True,
        ).pack(side="left", padx=12)

        self._make_button(
            btn_row, "✔  ALLOW ONCE",
            pal["btn_allow"]["bg"], pal["btn_allow"]["fg"],
            pal["btn_allow"]["active"], self._action_allow,
        ).pack(side="left", padx=12)

        self._make_button(
            btn_row, "★  ADD TO WHITELIST",
            pal["btn_allow"]["bg"], pal["btn_allow"]["fg"],
            pal["btn_allow"]["active"], self._action_whitelist,
        ).pack(side="left", padx=12)

        self._make_button(
            btn_row, "✕  DISMISS",
            pal["btn_dismiss"]["bg"], pal["btn_dismiss"]["fg"],
            pal["btn_dismiss"]["active"], self._dismiss,
        ).pack(side="left", padx=12)

        # ── Countdown label ──────────────────────────────────────────────
        self._countdown_label = tk.Label(
            center,
            text="",
            bg=pal["bg_base"],
            fg=pal["subtitle"],
            font=(FONT_FAMILY, 10, "normal"),
        )
        self._countdown_label.pack(pady=(6, 0))

        if self._countdown:
            self._update_countdown_label()

        # ── Bottom stripe ────────────────────────────────────────────────
        bottom_stripe = tk.Frame(self, bg=pal["header_bg"], height=6)
        bottom_stripe.pack(fill="x", side="bottom")

    # ------------------------------------------------------------------
    # Info rows builder
    # ------------------------------------------------------------------

    def _build_info_rows(self):
        pal = self._pal
        event = self._event
        rows = []

        # What happened
        rows.append(("What Happened", event.description, pal["body_text"]))

        # Device info
        if event.device_id:
            rows.append(("Device ID", event.device_id, pal["subtitle"]))

        extra = event.extra or {}
        if extra.get("vid") and extra.get("pid"):
            rows.append((
                "Device (VID:PID)",
                f"{extra['vid']}:{extra['pid']}",
                pal["accent2"],
            ))
        if extra.get("serial"):
            rows.append(("Serial", extra["serial"], pal["subtitle"]))
        if extra.get("class"):
            rows.append(("Device Class", extra["class"], pal["subtitle"]))

        # Threat-specific extra fields
        if extra.get("kps"):
            rows.append((
                "Keystroke Speed",
                f"{extra['kps']} keys/sec  (human max ≈ 15 keys/sec)",
                "#FF6B6B",
            ))
        if extra.get("confidence"):
            rows.append((
                "Detection Confidence",
                f"{extra['confidence']}%",
                pal["accent"],
            ))
        if extra.get("entropy"):
            rows.append((
                "File Entropy",
                f"{extra['entropy']:.2f} bits  (≥ 7.2 = packed/encrypted)",
                "#FF6B6B",
            ))
        if extra.get("drive"):
            rows.append(("USB Drive", extra["drive"], pal["subtitle"]))
        if extra.get("mb"):
            rows.append((
                "Data Volume",
                f"{extra['mb']:.1f} MB copied in 60 seconds",
                "#FF6B6B",
            ))

        # What USBShield did
        status = "Device BLOCKED automatically" if extra.get("blocked") else \
                 "Awaiting your decision"
        rows.append(("USBShield Action", status,
                     "#00DD80" if extra.get("blocked") else pal["accent2"]))

        return rows

    # ------------------------------------------------------------------
    # Recommended action text
    # ------------------------------------------------------------------

    def _recommended_action(self) -> str:
        cat = self._event.category
        mapping = {
            "HIDDetector":     "Unplug the suspicious USB device immediately, then click BLOCK DEVICE",
            "DeviceMonitor":   "Click BLOCK DEVICE to disable the USB device, then unplug it",
            "StorageGuard":    "Do NOT open any files on this drive — unplug and scan with antivirus",
            "FileScanner":     "Do NOT execute any files from this USB drive",
            "NetworkGuard":    "Unplug the USB network adapter immediately — your traffic may be intercepted",
            "DriverMonitor":   "Reboot and run a full system scan — kernel-level malware may be present",
        }
        return mapping.get(cat, "Unplug the USB device immediately and investigate")

    # ------------------------------------------------------------------
    # Auto-dismiss logic
    # ------------------------------------------------------------------

    @staticmethod
    def _auto_dismiss_seconds(sev: str) -> int:
        return {"MEDIUM": 30, "HIGH": 60, "CRITICAL": 0, "LOW": 20, "INFO": 15}.get(sev, 60)

    def _update_countdown_label(self) -> None:
        if self._dismissed or not self._countdown:
            return
        if self._countdown_remaining <= 0:
            self._dismiss()
            return
        self._countdown_label.config(
            text=f"Auto-dismiss in {self._countdown_remaining} seconds   |   Press ESC to dismiss now"
        )
        self._countdown_remaining -= 1
        self.after(1000, self._update_countdown_label)

    # ------------------------------------------------------------------
    # Animations
    # ------------------------------------------------------------------

    def _start_animations(self) -> None:
        self._pulse()
        self._blink_title()

    def _pulse(self) -> None:
        if self._dismissed:
            return
        col = self._pal["bg_pulse_a"] if self._pulse_state else self._pal["bg_pulse_b"]
        self._pulse_state = not self._pulse_state

        # Apply to all relevant frames
        try:
            self.configure(bg=col)
            for widget in self.winfo_children():
                if isinstance(widget, tk.Frame):
                    self._repaint_frame(widget, col)
        except tk.TclError:
            return

        self.after(self.PULSE_INTERVAL_MS, self._pulse)

    def _repaint_frame(self, frame: tk.Frame, col: str) -> None:
        """Recursively repaint frames with the pulse background color,
        skipping header frames and info cards that have their own colors."""
        try:
            cur = frame.cget("bg")
            # Only repaint frames that are currently using bg_base colors
            pal = self._pal
            if cur in (pal["bg_base"], pal["bg_pulse_a"], pal["bg_pulse_b"]):
                frame.configure(bg=col)
                for child in frame.winfo_children():
                    self._repaint_child(child, col)
        except Exception:
            pass

    def _repaint_child(self, widget, col: str) -> None:
        try:
            pal = self._pal
            cur = widget.cget("bg")
            if cur in (pal["bg_base"], pal["bg_pulse_a"], pal["bg_pulse_b"]):
                widget.configure(bg=col)
            if isinstance(widget, tk.Frame):
                for child in widget.winfo_children():
                    self._repaint_child(child, col)
        except Exception:
            pass

    def _blink_title(self) -> None:
        if self._dismissed:
            return
        try:
            col = self._pal["title_color"] if self._blink_state else self._pal["accent"]
            self._title_label.configure(fg=col)
        except tk.TclError:
            return
        self._blink_state = not self._blink_state
        self.after(self.TITLE_BLINK_MS, self._blink_title)

    # ------------------------------------------------------------------
    # Button factory
    # ------------------------------------------------------------------

    @staticmethod
    def _make_button(parent, text, bg, fg, active_bg, command, large=False):
        size = 14 if large else 12
        pad_x = 28 if large else 20
        pad_y = 14 if large else 10
        btn = tk.Button(
            parent,
            text=text,
            bg=bg,
            fg=fg,
            activebackground=active_bg,
            activeforeground=fg,
            font=(FONT_FAMILY, size, "bold"),
            relief="flat",
            bd=0,
            cursor="hand2",
            padx=pad_x,
            pady=pad_y,
            command=command,
        )
        btn.bind("<Enter>", lambda e: btn.configure(bg=active_bg))
        btn.bind("<Leave>", lambda e: btn.configure(bg=bg))
        return btn

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def _action_block(self) -> None:
        if self._on_block:
            self._on_block(self._event)
        self._dismiss()

    def _action_allow(self) -> None:
        if self._on_allow:
            self._on_allow(self._event)
        self._dismiss()

    def _action_whitelist(self) -> None:
        if self._on_whitelist:
            self._on_whitelist(self._event)
        self._dismiss()

    def _dismiss(self) -> None:
        if self._dismissed:
            return
        self._dismissed = True
        if self._on_dismiss:
            self._on_dismiss(self._event)
        try:
            self.destroy()
        except tk.TclError:
            pass

    # ------------------------------------------------------------------
    # Sound
    # ------------------------------------------------------------------

    def _play_alert_sound(self, sev: str) -> None:
        if sev == "CRITICAL":
            # Three urgent beeps
            def beeps():
                for _ in range(3):
                    _beep(1500, 200)
                    time.sleep(0.1)
            threading.Thread(target=beeps, daemon=True).start()
        elif sev == "HIGH":
            _beep_async(1200, 400)
        else:
            _beep_async(900, 250)


# ---------------------------------------------------------------------------
# AlertManager — singleton that queues and shows alerts one at a time
# ---------------------------------------------------------------------------

class AlertManager:
    """
    Receives threat events and shows FullScreenAlert windows in order.
    Must be used from the tkinter main thread (uses `after()` scheduling).
    """

    def __init__(self, root: tk.Tk):
        self._root  = root
        self._queue = []
        self._showing = False

        # External action callbacks
        self.on_block:     Optional[Callable] = None
        self.on_allow:     Optional[Callable] = None
        self.on_whitelist: Optional[Callable] = None

    def show_event(self, event) -> None:
        """Thread-safe: queue a threat event to show as a full-screen alert."""
        # Only show alerts for MEDIUM and above
        try:
            from core.threat_logger import Severity, SEVERITY_ORDER
            if SEVERITY_ORDER.get(event.severity, 0) < SEVERITY_ORDER[Severity.MEDIUM]:
                return
        except Exception:
            pass

        self._queue.append(event)
        self._root.after(0, self._try_show_next)

    def _try_show_next(self) -> None:
        if self._showing or not self._queue:
            return
        event = self._queue.pop(0)
        self._showing = True
        FullScreenAlert(
            self._root, event,
            on_block     = self._handle_block,
            on_allow     = self._handle_allow,
            on_whitelist = self._handle_whitelist,
            on_dismiss   = self._handle_dismiss,
        )

    def _handle_block(self, event) -> None:
        if self.on_block:
            self.on_block(event)

    def _handle_allow(self, event) -> None:
        if self.on_allow:
            self.on_allow(event)

    def _handle_whitelist(self, event) -> None:
        if self.on_whitelist:
            self.on_whitelist(event)

    def _handle_dismiss(self, event) -> None:
        self._showing = False
        # Show next alert if queued
        self._root.after(500, self._try_show_next)
