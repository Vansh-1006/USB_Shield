"""
USBShield - Theme
==================
Color constants, font sizes and style tokens for the USBShield GUI.
"""

# ===========================================================================
# Base dark theme
# ===========================================================================
BG_DEEP    = "#0A0A0F"    # window background
BG_PANEL   = "#12121A"    # card / panel background
BG_SIDEBAR = "#0D0D15"    # sidebar background
BG_ENTRY   = "#1A1A26"    # input / table row background
BG_ROW_ALT = "#141420"    # alternating table row

BORDER     = "#2A2A40"    # subtle border
BORDER_HL  = "#4A4A70"    # highlighted border

# Text
FG_PRIMARY   = "#EAEAF4"  # main text
FG_SECONDARY = "#8888AA"  # dimmed / label text
FG_DISABLED  = "#4A4A60"

# Accent (shield blue)
ACCENT      = "#4A7BFF"
ACCENT_DARK = "#2A5BDD"
ACCENT_GLOW = "#6A9BFF"

# ===========================================================================
# Severity palette
# ===========================================================================
SEV_COLORS = {
    "INFO":     {"fg": "#7EC8E3", "bg": "#0E1F28", "badge": "#7EC8E3", "badge_fg": "#000000"},
    "LOW":      {"fg": "#A8E6CF", "bg": "#0E2219", "badge": "#A8E6CF", "badge_fg": "#000000"},
    "MEDIUM":   {"fg": "#FFD700", "bg": "#27200A", "badge": "#FFD700", "badge_fg": "#000000"},
    "HIGH":     {"fg": "#FF8C00", "bg": "#271600", "badge": "#FF8C00", "badge_fg": "#000000"},
    "CRITICAL": {"fg": "#FF3B30", "bg": "#270A08", "badge": "#FF3B30", "badge_fg": "#FFFFFF"},
}

# ===========================================================================
# Full-screen alert palette (RED-dominant)
# ===========================================================================
ALERT_PALETTES = {
    "CRITICAL": {
        "bg_base":     "#6B0000",   # deep blood red
        "bg_pulse_a":  "#8B0000",   # pulse state A
        "bg_pulse_b":  "#4A0000",   # pulse state B (darker flash)
        "header_bg":   "#3D0000",   # top stripe
        "accent":      "#FF0000",   # pure red accents
        "accent2":     "#FF4444",   # lighter red
        "badge_bg":    "#FF0000",
        "badge_fg":    "#FFFFFF",
        "title_color": "#FFFFFF",
        "subtitle":    "#FFB3B3",
        "body_text":   "#FFDDDD",
        "info_bg":     "#3D0000",
        "info_border": "#8B0000",
        "btn_block":   {"bg": "#FF0000", "fg": "#FFFFFF", "active": "#CC0000"},
        "btn_allow":   {"bg": "#5A0000", "fg": "#FF8888", "active": "#4A0000"},
        "btn_dismiss": {"bg": "#3A0000", "fg": "#AA5555", "active": "#2A0000"},
        "glow":        "#FF000040",
        "icon":        "🚨",
        "severity_label": "CRITICAL THREAT",
    },
    "HIGH": {
        "bg_base":     "#7A1200",
        "bg_pulse_a":  "#9A1800",
        "bg_pulse_b":  "#5A0D00",
        "header_bg":   "#4A0A00",
        "accent":      "#FF4500",
        "accent2":     "#FF6B35",
        "badge_bg":    "#FF4500",
        "badge_fg":    "#FFFFFF",
        "title_color": "#FFFFFF",
        "subtitle":    "#FFCCBB",
        "body_text":   "#FFE4D6",
        "info_bg":     "#4A0A00",
        "info_border": "#9A1800",
        "btn_block":   {"bg": "#FF4500", "fg": "#FFFFFF", "active": "#CC3800"},
        "btn_allow":   {"bg": "#5A1000", "fg": "#FFAA80", "active": "#4A0D00"},
        "btn_dismiss": {"bg": "#3A0A00", "fg": "#AA7755", "active": "#2A0800"},
        "glow":        "#FF450040",
        "icon":        "⚠",
        "severity_label": "HIGH SEVERITY THREAT",
    },
    "MEDIUM": {
        "bg_base":     "#6B2E00",
        "bg_pulse_a":  "#8B3A00",
        "bg_pulse_b":  "#4A2000",
        "header_bg":   "#3D1A00",
        "accent":      "#FF8C00",
        "accent2":     "#FFB347",
        "badge_bg":    "#FF8C00",
        "badge_fg":    "#000000",
        "title_color": "#FFFFFF",
        "subtitle":    "#FFE4B3",
        "body_text":   "#FFF0D6",
        "info_bg":     "#3D1A00",
        "info_border": "#8B3A00",
        "btn_block":   {"bg": "#FF8C00", "fg": "#000000", "active": "#CC7000"},
        "btn_allow":   {"bg": "#5A2500", "fg": "#FFCC80", "active": "#4A1E00"},
        "btn_dismiss": {"bg": "#3A1A00", "fg": "#AA8855", "active": "#2A1400"},
        "glow":        "#FF8C0040",
        "icon":        "⚡",
        "severity_label": "MEDIUM SEVERITY THREAT",
    },
}


# ===========================================================================
# Button styles
# ===========================================================================
BTN_PRIMARY = {
    "bg": ACCENT, "fg": "#FFFFFF",
    "activebackground": ACCENT_DARK, "activeforeground": "#FFFFFF",
    "relief": "flat", "bd": 0, "cursor": "hand2",
    "padx": 16, "pady": 8,
}
BTN_DANGER = {
    "bg": "#CC0000", "fg": "#FFFFFF",
    "activebackground": "#990000", "activeforeground": "#FFFFFF",
    "relief": "flat", "bd": 0, "cursor": "hand2",
    "padx": 16, "pady": 8,
}
BTN_GHOST = {
    "bg": BG_PANEL, "fg": FG_SECONDARY,
    "activebackground": BG_ENTRY, "activeforeground": FG_PRIMARY,
    "relief": "flat", "bd": 0, "cursor": "hand2",
    "padx": 12, "pady": 6,
}

# ===========================================================================
# Status indicator colors
# ===========================================================================
STATUS_ACTIVE   = "#00D26A"   # green — protection running
STATUS_WARNING  = "#FFD700"   # yellow — degraded
STATUS_INACTIVE = "#FF3B30"   # red — stopped
STATUS_UNKNOWN  = "#8888AA"   # grey

# ===========================================================================
# Fonts  (tkinter font tuples: (family, size, weight))
# ===========================================================================
FONT_FAMILY = "Segoe UI"

FONT_TITLE      = (FONT_FAMILY, 18, "bold")
FONT_SUBTITLE   = (FONT_FAMILY, 12, "normal")
FONT_HEADING    = (FONT_FAMILY, 11, "bold")
FONT_BODY       = (FONT_FAMILY, 10, "normal")
FONT_SMALL      = (FONT_FAMILY, 9, "normal")
FONT_MONO       = ("Consolas", 9, "normal")
FONT_MONO_SM    = ("Consolas", 8, "normal")
FONT_ALERT_HUGE = (FONT_FAMILY, 42, "bold")
FONT_ALERT_BIG  = (FONT_FAMILY, 24, "bold")
FONT_ALERT_MED  = (FONT_FAMILY, 16, "normal")
FONT_ALERT_BODY = (FONT_FAMILY, 13, "normal")
FONT_BADGE      = (FONT_FAMILY, 11, "bold")

# ===========================================================================
# Layout
# ===========================================================================
SIDEBAR_WIDTH  = 200
PADDING_OUTER  = 20
PADDING_INNER  = 12
CARD_RADIUS    = 8     # pixels (simulated with Canvas or relief)
ROW_HEIGHT     = 28
