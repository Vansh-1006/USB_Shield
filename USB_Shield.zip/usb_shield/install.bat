@echo off
setlocal EnableDelayedExpansion
title USBShield Installer

echo.
echo  =====================================================
echo    USBShield - USB Attack Prevention System
echo    Installer v1.0.0
echo  =====================================================
echo.

:: ── Check for Python ────────────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python is not installed or not in PATH.
    echo  Please install Python 3.9+ from https://www.python.org
    pause
    exit /b 1
)

for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo  [OK]  Python %PYVER% found

:: ── Check for pip ───────────────────────────────────────────────────────
pip --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] pip is not available.
    pause
    exit /b 1
)
echo  [OK]  pip found

:: ── Upgrade pip silently ────────────────────────────────────────────────
echo  [..] Upgrading pip...
python -m pip install --upgrade pip --quiet

:: ── Install dependencies ─────────────────────────────────────────────────
echo.
echo  [..] Installing dependencies...
echo.

set PACKAGES=pywin32 wmi watchdog psutil colorama

for %%P in (%PACKAGES%) do (
    echo  [..] Installing %%P ...
    pip install %%P --quiet
    if errorlevel 1 (
        echo  [WARN] Could not install %%P  -- some features may be unavailable
    ) else (
        echo  [OK]  %%P installed
    )
)

:: ── pywin32 post-install ─────────────────────────────────────────────────
echo.
echo  [..] Running pywin32 post-install script...
python -c "import win32com.client" >nul 2>&1
if errorlevel 1 (
    python Scripts\pywin32_postinstall.py -install >nul 2>&1
)
echo  [OK]  pywin32 configured

:: ── Create logs directory ────────────────────────────────────────────────
if not exist logs mkdir logs
echo  [OK]  logs\ directory ready

:: ── Done ────────────────────────────────────────────────────────────────
echo.
echo  =====================================================
echo    Installation complete!
echo.
echo    To start USBShield:
echo      Double-click  run_as_admin.bat
echo    OR right-click it and choose "Run as administrator"
echo  =====================================================
echo.
pause
endlocal
