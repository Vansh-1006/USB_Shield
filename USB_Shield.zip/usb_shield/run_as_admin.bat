@echo off
setlocal
title USBShield Launcher

:: ── Self-elevate via PowerShell UAC prompt ──────────────────────────────
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  [USBShield] Requesting Administrator privileges...
    powershell -Command ^
        "Start-Process -FilePath '%~f0' -Verb RunAs -Wait"
    exit /b
)

:: ── Now running as Administrator ─────────────────────────────────────────
cd /d "%~dp0"

echo.
echo  =====================================================
echo    USBShield - USB Attack Prevention System
echo    Starting with Administrator privileges...
echo  =====================================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found. Run install.bat first.
    pause
    exit /b 1
)

:: Launch USBShield
python main.py %*

if errorlevel 1 (
    echo.
    echo  [ERROR] USBShield exited with an error.
    echo  Check logs\ directory for details.
    pause
)
endlocal
