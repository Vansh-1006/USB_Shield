"""
Generate binary test payload files for USB.
Run this script ONCE before copying files to USB:
    python generate_binary_payloads.py

Creates:
  ransomware_sim.exe  — high-entropy PE file (triggers HighEntropy + PE detection)
  invoice.pdf         — PE header in .pdf file (triggers MaskedExecutable)
"""
import os
import struct
import random

script_dir = os.path.dirname(os.path.abspath(__file__))
random.seed(0xDEADBEEF)

def make_pe_header():
    pe = bytearray(256)
    pe[0:2] = b'MZ'
    struct.pack_into('<I', pe, 0x3C, 0x40)
    pe[0x40:0x44] = b'PE\x00\x00'
    return bytes(pe)

pe_hdr    = make_pe_header()
rand_body = bytes(random.randint(0, 255) for _ in range(200_000))

# ransomware_sim.exe — high entropy + PE header
ransom_path = os.path.join(script_dir, 'ransomware_sim.exe')
with open(ransom_path, 'wb') as f:
    f.write(pe_hdr + rand_body)
print(f"Created: ransomware_sim.exe  ({len(pe_hdr)+len(rand_body):,} bytes, entropy ~7.99 bits)")

# invoice.pdf — PE inside wrong container
pdf_path = os.path.join(script_dir, 'invoice.pdf')
with open(pdf_path, 'wb') as f:
    f.write(pe_hdr + rand_body[:50_000])
print(f"Created: invoice.pdf         ({len(pe_hdr)+50_000:,} bytes, PE header inside .pdf)")

print("\nAll binary payloads generated. Copy the usb_payloads/ folder to your USB drive.")
print("Insert the USB drive while USBShield is running to trigger detection.")
