"""
USBShield - Storage Guard  (v2 — fixed)
========================================
FIXED ISSUES:
  • ONE summary alert per drive (not one per file)
  • Per-drive cooldown (60 s) on ongoing watchdog alerts
  • Individual file threats marked is_file_scan=True → no full-screen alert
  • Drive summary marked is_drive_summary=True → one full-screen alert per scan
  • Only HIGH/CRITICAL file threats produce any alert at all

Covers attacks: #6 #7 #8 #9 #10 #11 #12 #13
"""

import os
import string
import threading
import time
from datetime import datetime
from typing import Callable, Dict, List, Optional, Set

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    _WATCHDOG = True
except ImportError:
    _WATCHDOG = False

from core.file_scanner import FileScanner, ThreatLevel


SENSITIVE_EXTENSIONS = {
    ".kdbx", ".pfx", ".p12", ".pem", ".key", ".ppk",
    ".sql", ".db", ".sqlite", ".accdb",
    ".pst", ".ost",
    ".wallet", ".dat",
    ".ovpn", ".rdp",
    "ntds.dit", "sam", "security", "system",
}

EXFIL_VOLUME_MB      = 100
EXFIL_WINDOW_SECONDS = 60
EXFIL_FILE_COUNT     = 50
DRIVE_ALERT_COOLDOWN = 60   # seconds between watchdog alerts for same drive


class _DriveHandler(FileSystemEventHandler):
    def __init__(self, drive: str, guard: "StorageGuard"):
        super().__init__()
        self._drive       = drive
        self._guard       = guard
        self._window_start = time.monotonic()
        self._window_bytes = 0
        self._window_count = 0

    def on_created(self, event):
        if not event.is_directory:
            self._guard._on_file_appeared(self._drive, event.src_path)
            self._track_write(event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            self._track_write(event.src_path)

    def on_moved(self, event):
        if not event.is_directory:
            self._track_write(event.dest_path)

    def _track_write(self, path: str) -> None:
        try:
            size = os.path.getsize(path)
        except OSError:
            size = 0

        now = time.monotonic()
        if now - self._window_start > EXFIL_WINDOW_SECONDS:
            self._window_start = now
            self._window_bytes = 0
            self._window_count = 0

        self._window_bytes += size
        self._window_count += 1

        mb = self._window_bytes / (1024 * 1024)
        if mb >= EXFIL_VOLUME_MB or self._window_count >= EXFIL_FILE_COUNT:
            self._guard._on_exfiltration(self._drive, mb, self._window_count)
            self._window_bytes = 0
            self._window_count = 0

        fname = os.path.basename(path).lower()
        ext   = os.path.splitext(fname)[1].lower()
        if ext in SENSITIVE_EXTENSIONS or fname in SENSITIVE_EXTENSIONS:
            self._guard._on_sensitive_file(self._drive, path)


class StorageGuard:
    """
    Monitors USB storage drives with smart alert batching.

    Callbacks:
        on_new_drive(drive, threats)
        on_exfiltration(drive, mb, count)
        on_sensitive_copy(drive, path)
        on_file_threat(drive, threat)
    """

    POLL_INTERVAL = 2.0

    def __init__(self, file_scanner: FileScanner, logger):
        self._scanner = file_scanner
        self._log     = logger
        self._running = False
        self._thread: Optional[threading.Thread] = None

        self._known_drives: Set[str] = set()
        self._drive_lock = threading.Lock()

        self._observers: Dict[str, object] = {}

        # Per-drive cooldown for ongoing watchdog alerts
        self._last_drive_alert: Dict[str, float] = {}
        self._cooldown_lock = threading.Lock()

        self.on_new_drive:      Optional[Callable] = None
        self.on_exfiltration:   Optional[Callable] = None
        self.on_sensitive_copy: Optional[Callable] = None
        self.on_file_threat:    Optional[Callable] = None

        self.auto_delete_autorun   = True
        self.drive_alert_cooldown  = DRIVE_ALERT_COOLDOWN

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        with self._drive_lock:
            self._known_drives = set(self._get_removable_drives())
        self._thread = threading.Thread(
            target=self._poll_loop, daemon=True, name="StorageGuard"
        )
        self._thread.start()
        self._log.info("StorageGuard", "Storage guard started",
                       f"Watching removable drives. Current: {self._known_drives}")

    def stop(self) -> None:
        self._running = False
        for obs in self._observers.values():
            try:
                obs.stop()
                obs.join(timeout=3)
            except Exception:
                pass
        self._observers.clear()

    # ------------------------------------------------------------------
    # Drive polling
    # ------------------------------------------------------------------

    def _poll_loop(self) -> None:
        while self._running:
            try:
                current = set(self._get_removable_drives())
                with self._drive_lock:
                    known = set(self._known_drives)

                for drive in current - known:
                    self._on_drive_inserted(drive)
                for drive in known - current:
                    self._on_drive_removed(drive)

                with self._drive_lock:
                    self._known_drives = current
            except Exception as exc:
                self._log.medium("StorageGuard", "Poll error", str(exc))
            time.sleep(self.POLL_INTERVAL)

    @staticmethod
    def _get_removable_drives() -> List[str]:
        removable = []
        try:
            import ctypes
            bitmask    = ctypes.windll.kernel32.GetLogicalDrives()
            drive_type = ctypes.windll.kernel32.GetDriveTypeW
            for i, letter in enumerate(string.ascii_uppercase):
                if bitmask & (1 << i):
                    drive = f"{letter}:\\"
                    if drive_type(drive) == 2:   # DRIVE_REMOVABLE
                        removable.append(drive)
        except Exception:
            pass
        return removable

    # ------------------------------------------------------------------
    # Drive events
    # ------------------------------------------------------------------

    def _on_drive_inserted(self, drive: str) -> None:
        self._log.high("StorageGuard", f"USB drive inserted: {drive}",
                       "Scanning for threats...")

        # 1. Neutralise autorun.inf immediately
        self._handle_autorun(drive)

        # 2. Full scan
        threats = self._scanner.scan_directory(drive)
        critical_threats = [t for t in threats
                            if t.level in (ThreatLevel.HIGH, ThreatLevel.CRITICAL)]
        medium_threats   = [t for t in threats if t.level == ThreatLevel.MEDIUM]

        # 3. Fire ONE summary event (not one per file)
        if critical_threats:
            categories = list(dict.fromkeys(t.category for t in critical_threats))
            summary_desc = (
                f"Found {len(critical_threats)} threat(s) on {drive}: "
                + ", ".join(f"{t.category}: {os.path.basename(t.path)}"
                            for t in critical_threats[:5])
                + ("..." if len(critical_threats) > 5 else "")
            )
            from core.threat_logger import Severity
            worst_sev = (Severity.CRITICAL
                         if any(t.level == ThreatLevel.CRITICAL for t in critical_threats)
                         else Severity.HIGH)
            self._log.log(
                "StorageGuard", worst_sev,
                f"USB Drive {drive} — {len(critical_threats)} threat(s) detected",
                summary_desc,
                extra={
                    "drive":            drive,
                    "threat_count":     len(critical_threats),
                    "medium_count":     len(medium_threats),
                    "categories":       categories,
                    "is_drive_summary": True,   # ← shows ONE full-screen alert
                },
            )
        else:
            self._log.info("StorageGuard",
                           f"USB Drive {drive} — scan clean",
                           f"No HIGH/CRITICAL threats found ({len(medium_threats)} medium)")

        # 4. Log individual critical threats to the log panel (no full-screen alert)
        for t in critical_threats:
            from core.threat_logger import Severity
            sev = Severity.CRITICAL if t.level == ThreatLevel.CRITICAL else Severity.HIGH
            self._log.log(
                "FileScanner", sev,
                f"Threat: {os.path.basename(t.path)}",
                t.description,
                extra={
                    "drive":          drive,
                    "path":           t.path,
                    "category":       t.category,
                    "entropy":        t.entropy,
                    "is_file_scan":   True,   # ← suppresses full-screen alert
                },
            )
            if self.on_file_threat:
                self.on_file_threat(drive, t)

        if self.on_new_drive:
            self.on_new_drive(drive, threats)

        # 5. Start watchdog for ongoing monitoring
        self._start_watchdog(drive)

    def _on_drive_removed(self, drive: str) -> None:
        self._log.info("StorageGuard", f"USB drive removed: {drive}", "")
        obs = self._observers.pop(drive, None)
        if obs:
            try:
                obs.stop()
                obs.join(timeout=3)
            except Exception:
                pass
        with self._cooldown_lock:
            self._last_drive_alert.pop(drive, None)

    def _on_file_appeared(self, drive: str, path: str) -> None:
        """Watchdog event — new file written to USB drive."""
        threats = self._scanner.scan_file(path)
        critical = [t for t in threats
                    if t.level in (ThreatLevel.HIGH, ThreatLevel.CRITICAL)]
        if not critical:
            return

        # Per-drive cooldown: max one full-screen alert per drive per N seconds.
        # Default last=-inf so a drive never seen before ALWAYS fires immediately.
        now = time.monotonic()
        with self._cooldown_lock:
            last = self._last_drive_alert.get(drive, float('-inf'))
            if now - last < self.drive_alert_cooldown:
                # Still log to panel but suppress full-screen alert
                for t in critical:
                    from core.threat_logger import Severity
                    self._log.log(
                        "FileScanner", Severity.HIGH,
                        f"New threat file (cooldown): {os.path.basename(path)}",
                        t.description,
                        extra={"drive": drive, "path": path,
                               "is_file_scan": True},
                    )
                return
            self._last_drive_alert[drive] = now

        # Fire one alert for this new file
        t = critical[0]
        from core.threat_logger import Severity
        sev = Severity.CRITICAL if t.level == ThreatLevel.CRITICAL else Severity.HIGH
        self._log.log(
            "StorageGuard", sev,
            f"New malicious file on {drive}: {os.path.basename(path)}",
            t.description,
            extra={
                "drive":            drive,
                "path":             path,
                "category":         t.category,
                "is_drive_summary": True,  # trigger full-screen alert
            },
        )
        if self.on_file_threat:
            self.on_file_threat(drive, t)

    def _on_exfiltration(self, drive: str, mb: float, count: int) -> None:
        self._log.critical(
            "StorageGuard",
            "Data Exfiltration Detected",
            f"{mb:.1f} MB / {count} files copied to {drive} in "
            f"{EXFIL_WINDOW_SECONDS}s",
            extra={"drive": drive, "mb": mb, "file_count": count,
                   "is_drive_summary": True},
        )
        if self.on_exfiltration:
            self.on_exfiltration(drive, mb, count)

    def _on_sensitive_file(self, drive: str, path: str) -> None:
        fname = os.path.basename(path)
        self._log.high(
            "StorageGuard",
            "Sensitive File Copied to USB",
            f"'{fname}' written to {drive} — possible data theft",
            extra={"drive": drive, "path": path,
                   "is_drive_summary": True},
        )
        if self.on_sensitive_copy:
            self.on_sensitive_copy(drive, path)

    # ------------------------------------------------------------------
    # Autorun handling
    # ------------------------------------------------------------------

    def _handle_autorun(self, drive: str) -> None:
        autorun_path = os.path.join(drive, "autorun.inf")
        if not os.path.exists(autorun_path):
            return
        self._log.high("StorageGuard", "autorun.inf detected",
                       f"autorun.inf found on {drive} — neutralising",
                       extra={"drive": drive, "is_drive_summary": True})
        if self.auto_delete_autorun:
            try:
                os.remove(autorun_path)
                self._log.info("StorageGuard", "autorun.inf deleted",
                               f"Removed from {drive}")
            except PermissionError:
                try:
                    os.rename(autorun_path,
                              os.path.join(drive, "autorun.inf.BLOCKED"))
                except Exception:
                    pass
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Watchdog
    # ------------------------------------------------------------------

    def _start_watchdog(self, drive: str) -> None:
        if not _WATCHDOG or drive in self._observers:
            return
        try:
            handler  = _DriveHandler(drive, self)
            observer = Observer()
            observer.schedule(handler, drive, recursive=True)
            observer.start()
            self._observers[drive] = observer
        except Exception as exc:
            self._log.medium("StorageGuard", "Watchdog error", str(exc))
