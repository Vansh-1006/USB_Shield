"""
USBShield - File Scanner
=========================
Static analysis of files on USB storage devices.

Covers attacks:
  • USB storage-based malware         (attack  #6)
  • USB malware/worm propagation      (attack  #7)
  • USB autorun attacks               (attack  #8)
  • Malicious USB scripts/documents   (attack  #9)
  • USB ransomware delivery           (attack #10)
  • USB trojan/loader delivery        (attack #11)
"""

import math
import os
import re
import struct
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Extensions that warrant automatic flagging
DANGEROUS_EXTENSIONS = {
    # Executables / loaders
    ".exe", ".dll", ".scr", ".com", ".pif",
    # Scripts
    ".bat", ".cmd", ".ps1", ".psm1", ".psd1",
    ".vbs", ".vbe", ".js", ".jse", ".wsf", ".wsh",
    ".hta", ".msc", ".cpl",
    # Macros / Office
    ".xlsm", ".xlsb", ".xltm", ".docm", ".dotm",
    ".pptm", ".ppam", ".potm", ".ppsm",
    # Installers
    ".msi", ".msp", ".mst", ".msix",
    # Link files (LNK can point to payloads)
    ".lnk", ".url",
    # Python / other interpreted
    ".py", ".rb", ".php",
    # Archives (may contain malware)
    ".iso", ".img",
    # Autorun descriptor
    ".inf",
}

HIGH_ENTROPY_THRESHOLD = 7.2     # bits — packed/encrypted files > 7.2
AUTORUN_FILENAME       = "autorun.inf"
MAX_SCRIPT_SCAN_BYTES  = 512_000  # 512 KB — max bytes read for text analysis
MAX_PE_SCAN_BYTES      = 4_096    # 4 KB — enough for PE headers

# Obfuscation / malware patterns (regex strings for heuristic script analysis)
SCRIPT_PATTERNS: List[Tuple[str, str, str]] = [
    # (pattern, severity, description)
    (r"(?i)(invoke-expression|iex)\s*[(\[`]",      "HIGH",   "PowerShell IEX — likely executing remote/encoded payload"),
    (r"(?i)frombase64string",                       "HIGH",   "Base64 decode — common payload obfuscation technique"),
    (r"(?i)downloadstring|downloadfile|webclient",  "HIGH",   "Network download attempt in script"),
    (r"(?i)(bypass.*executionpolicy|executionpolicy.*bypass)", "HIGH", "PowerShell execution policy bypass"),
    (r"(?i)hidden.*windowstyle|windowstyle.*hidden","MEDIUM", "Hidden window — concealing execution"),
    (r"(?i)-enc\s+[A-Za-z0-9+/=]{20,}",            "HIGH",   "Encoded PowerShell command"),
    (r"(?i)new-object\s+system\.net",               "MEDIUM", "Network object creation"),
    (r"(?i)shellexecute|shell\.run",                "MEDIUM", "Shell execution via script"),
    (r"(?i)wscript\.shell|createobject",            "MEDIUM", "WScript Shell object"),
    (r"(?i)certutil.*decode|certutil.*urlcache",    "HIGH",   "CertUtil abuse — used to decode/download payloads"),
    (r"(?i)mimikatz|sekurlsa|lsadump",              "CRITICAL","Known credential theft tool signature"),
    (r"(?i)meterpreter|metasploit|cobalt.?strike",  "CRITICAL","Known pentesting/malware framework signature"),
    (r"(?i)invoke-mimikatz|invoke-shellcode",       "CRITICAL","Invoke-Mimikatz or shellcode injection"),
    (r"(?i)\\\\.*\\c\$|\\\\.*\\admin\$",            "HIGH",   "UNC admin share access"),
    (r"(?i)reg\s+add.*HKLM.*run",                   "HIGH",   "Registry run-key persistence"),
    (r"(?i)schtasks.*\/create",                     "HIGH",   "Scheduled task creation — persistence"),
    (r"(?i)vssadmin.*delete.*shadows",              "HIGH",   "Shadow copy deletion — ransomware indicator"),
    (r"(?i)wevtutil.*cl.*system",                   "HIGH",   "Event log clearing — covering tracks"),
    (r"autorun\s*=",                                "HIGH",   "autorun.inf autorun entry"),
    (r"shellexecute\s*=",                           "HIGH",   "autorun.inf shellexecute entry"),
]

# Simple PE section name anomalies (packed malware often uses unusual names)
SUSPICIOUS_SECTION_NAMES = {b".upx0", b".upx1", b"UPX0", b"UPX1",
                             b".aspack", b".adata", b".themida",
                             b"execryptor", b".packed"}


class ThreatLevel(Enum):
    CLEAN    = "CLEAN"
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"


@dataclass
class FileThreat:
    path:        str
    level:       ThreatLevel
    category:    str
    description: str
    detail:      str = ""
    entropy:     Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "path":        self.path,
            "level":       self.level.value,
            "category":    self.category,
            "description": self.description,
            "detail":      self.detail,
            "entropy":     self.entropy,
        }


# ---------------------------------------------------------------------------
# Core analysis functions
# ---------------------------------------------------------------------------

def _compute_entropy(data: bytes) -> float:
    """Shannon entropy of byte data (0.0 – 8.0 bits per byte)."""
    if not data:
        return 0.0
    freq: Dict[int, int] = {}
    for b in data:
        freq[b] = freq.get(b, 0) + 1
    length = len(data)
    entropy = 0.0
    for count in freq.values():
        p = count / length
        if p > 0:
            entropy -= p * math.log2(p)
    return entropy


def _is_pe_file(data: bytes) -> bool:
    """Check MZ + PE magic bytes."""
    if len(data) < 64:
        return False
    if data[:2] != b"MZ":
        return False
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if pe_offset + 4 > len(data):
        return False
    return data[pe_offset: pe_offset + 4] == b"PE\x00\x00"


def _get_pe_sections(data: bytes) -> List[bytes]:
    """Extract section names from a PE binary (first 4 KB)."""
    if not _is_pe_file(data):
        return []
    try:
        pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
        machine   = struct.unpack_from("<H", data, pe_offset + 4)[0]
        # x86=0x14C  x64=0x8664
        opt_size  = struct.unpack_from("<H", data, pe_offset + 20)[0]
        num_sects = struct.unpack_from("<H", data, pe_offset + 6)[0]
        sect_off  = pe_offset + 24 + opt_size
        sections  = []
        for i in range(num_sects):
            base = sect_off + i * 40
            if base + 8 > len(data):
                break
            name = data[base: base + 8].rstrip(b"\x00")
            sections.append(name)
        return sections
    except Exception:
        return []


# ---------------------------------------------------------------------------
# FileScanner
# ---------------------------------------------------------------------------

class FileScanner:
    """
    Scans individual files or entire directories for USB-delivered threats.
    """

    def __init__(self, logger):
        self._log = logger

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scan_file(self, path: str) -> List[FileThreat]:
        """Scan a single file. Returns list of FileThreat objects found."""
        threats: List[FileThreat] = []
        if not os.path.isfile(path):
            return threats

        filename = os.path.basename(path).lower()
        ext      = os.path.splitext(filename)[1].lower()

        # 1. Autorun.inf
        if filename == AUTORUN_FILENAME:
            threats.append(
                FileThreat(path, ThreatLevel.HIGH, "Autorun",
                           "autorun.inf detected — USB autorun attack vector",
                           "autorun.inf allows automatic code execution when drive is inserted")
            )
            content_threats = self._scan_autorun_content(path)
            threats.extend(content_threats)

        # 2. Dangerous extension check
        if ext in DANGEROUS_EXTENSIONS and filename != AUTORUN_FILENAME:
            threats.append(
                FileThreat(path, ThreatLevel.MEDIUM, "DangerousExtension",
                           f"Executable/script file: {ext}",
                           f"Files of type {ext} can directly execute code")
            )

        # 3. Read file bytes (limited)
        try:
            with open(path, "rb") as f:
                header = f.read(MAX_PE_SCAN_BYTES)
        except (PermissionError, OSError):
            return threats

        # 4. PE analysis
        pe_threats = self._analyse_pe(path, header)
        threats.extend(pe_threats)

        # 5. Entropy analysis (full file — use streaming for large files)
        entropy = self._compute_file_entropy(path)
        if entropy is not None and entropy >= HIGH_ENTROPY_THRESHOLD:
            threats.append(
                FileThreat(path, ThreatLevel.HIGH, "HighEntropy",
                           f"High entropy ({entropy:.2f} bits) — packed or encrypted payload",
                           "Ransomware, packed trojans and shellcode have near-max entropy",
                           entropy=entropy)
            )

        # 6. Script content analysis
        if ext in {".ps1", ".bat", ".cmd", ".vbs", ".js", ".hta", ".wsf", ".inf",
                   ".psm1", ".psd1"}:
            script_threats = self._scan_script_content(path)
            threats.extend(script_threats)

        # 7. LNK file check (shortcuts can point to malicious payloads)
        if ext == ".lnk":
            threats.append(
                FileThreat(path, ThreatLevel.MEDIUM, "ShortcutFile",
                           "LNK shortcut file — may redirect to malicious executable",
                           "Malware often uses .lnk files to bypass extension awareness")
            )

        return threats

    def scan_directory(self, root: str, max_files: int = 5000) -> List[FileThreat]:
        """Walk a directory tree and scan all files."""
        all_threats: List[FileThreat] = []
        count = 0
        try:
            for dirpath, _dirs, files in os.walk(root):
                for filename in files:
                    if count >= max_files:
                        break
                    filepath = os.path.join(dirpath, filename)
                    threats  = self.scan_file(filepath)
                    all_threats.extend(threats)
                    if threats:
                        worst = max(t.level.value for t in threats)
                        self._log.log(
                            "FileScanner",
                            self._severity(worst),
                            f"Threat in file: {filename}",
                            f"{threats[0].description} — {filepath}",
                        )
                    count += 1
        except (PermissionError, OSError):
            pass
        return all_threats

    # ------------------------------------------------------------------
    # Internal analysis methods
    # ------------------------------------------------------------------

    def _analyse_pe(self, path: str, data: bytes) -> List[FileThreat]:
        threats = []
        if not _is_pe_file(data):
            return threats

        # Check section names for known packer signatures
        sections = _get_pe_sections(data)
        for sec in sections:
            if sec.lower() in {s.lower() for s in SUSPICIOUS_SECTION_NAMES}:
                threats.append(
                    FileThreat(
                        path, ThreatLevel.HIGH, "PackedPE",
                        f"Packed executable detected (section: {sec.decode(errors='replace')})",
                        "Packers like UPX/Themida are used to hide malicious code from AV",
                    )
                )
                break

        # PE on a USB drive with a non-executable extension is suspicious
        ext = os.path.splitext(path)[1].lower()
        if ext not in {".exe", ".dll", ".sys", ".scr", ".com", ".ocx", ".drv"}:
            threats.append(
                FileThreat(
                    path, ThreatLevel.HIGH, "MaskedExecutable",
                    f"PE executable disguised as {ext or 'no-extension'} file",
                    "Malware commonly renames .exe to .pdf/.jpg/.mp4 to deceive users",
                )
            )

        return threats

    def _scan_script_content(self, path: str) -> List[FileThreat]:
        threats = []
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read(MAX_SCRIPT_SCAN_BYTES)
        except (PermissionError, OSError):
            return threats

        for pattern, severity, description in SCRIPT_PATTERNS:
            if re.search(pattern, content):
                threats.append(
                    FileThreat(path, ThreatLevel[severity], "ScriptHeuristic",
                               description,
                               f"Pattern matched: {pattern[:60]}")
                )

        return threats

    def _scan_autorun_content(self, path: str) -> List[FileThreat]:
        threats = []
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read(4096)
        except (PermissionError, OSError):
            return threats

        for pattern, severity, description in SCRIPT_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                threats.append(
                    FileThreat(path, ThreatLevel[severity], "AutorunContent",
                               description,
                               "Found in autorun.inf content")
                )
        return threats

    @staticmethod
    def _compute_file_entropy(path: str) -> Optional[float]:
        """Read up to 1 MB and compute entropy."""
        try:
            with open(path, "rb") as f:
                data = f.read(1_048_576)
            return _compute_entropy(data)
        except (PermissionError, OSError):
            return None

    @staticmethod
    def _severity(level_str: str):
        from core.threat_logger import Severity
        mapping = {
            "CLEAN": Severity.INFO, "LOW": Severity.LOW,
            "MEDIUM": Severity.MEDIUM, "HIGH": Severity.HIGH,
            "CRITICAL": Severity.CRITICAL,
        }
        return mapping.get(level_str, Severity.MEDIUM)
