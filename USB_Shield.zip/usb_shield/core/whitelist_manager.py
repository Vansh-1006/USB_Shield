"""
USBShield - Whitelist Manager
Manages the approved USB device database (VID/PID pairs + device class rules).
Provides thread-safe add/remove/query operations and persists to JSON.

Covers attacks: BadUSB, Malicious HID peripherals, Rogue network interfaces,
                Unauthorized driver installation
"""

import json
import os
import threading
from datetime import datetime
from typing import Dict, List, Optional, Tuple


# Windows USB Device Class GUIDs → human-readable names
DEVICE_CLASSES = {
    "{36FC9E60-C465-11CF-8056-444553540000}": "USB Hub",
    "{745A17A0-74D3-11D0-B6FE-00A0C90F57DA}": "HID (Human Interface Device)",
    "{4D36E96B-E325-11CE-BFC1-08002BE10318}": "Keyboard",
    "{4D36E96F-E325-11CE-BFC1-08002BE10318}": "Mouse",
    "{4D36E967-E325-11CE-BFC1-08002BE10318}": "Disk Drive",
    "{4D36E980-E325-11CE-BFC1-08002BE10318}": "Floppy Disk Controller",
    "{4D36E978-E325-11CE-BFC1-08002BE10318}": "Ports (COM & LPT)",
    "{4D36E972-E325-11CE-BFC1-08002BE10318}": "Net (Network Adapter)",
    "{4D36E96A-E325-11CE-BFC1-08002BE10318}": "HDC (IDE/ATAPI)",
    "{6BDD1FC6-810F-11D0-BEC7-08002BE2092F}": "Image (Camera/Scanner)",
    "{4D36E968-E325-11CE-BFC1-08002BE10318}": "Display",
    "{6BDD1FC5-810F-11D0-BEC7-08002BE2092F}": "Media (Audio/Video)",
    "{EEC5AD98-8080-425F-922A-DABF3DE3F69A}": "WPD (Portable Device - MTP)",
    "{88BAE032-5A81-49F0-BC3D-A4FF138216D6}": "USB Serial (Modem)",
    "{4D36E96C-E325-11CE-BFC1-08002BE10318}": "Media (Sound)",
}

# Device classes considered high-risk when not whitelisted
HIGH_RISK_CLASSES = {
    "{4D36E972-E325-11CE-BFC1-08002BE10318}",  # Network adapter (RNDIS/CDC ECM)
    "{88BAE032-5A81-49F0-BC3D-A4FF138216D6}",  # USB Modem
}

# Device classes that can be used for HID injection
HID_CLASSES = {
    "{745A17A0-74D3-11D0-B6FE-00A0C90F57DA}",  # HID
    "{4D36E96B-E325-11CE-BFC1-08002BE10318}",  # Keyboard
    "{4D36E96F-E325-11CE-BFC1-08002BE10318}",  # Mouse
}


class WhitelistEntry:
    """Represents one approved device record."""

    def __init__(
        self,
        vid: str,
        pid: str,
        label: str,
        device_class: Optional[str] = None,
        trusted_hid: bool = False,
        serial: Optional[str] = None,
        added_by: str = "user",
    ):
        self.vid = vid.upper()
        self.pid = pid.upper()
        self.label = label
        self.device_class = device_class
        self.trusted_hid = trusted_hid   # HID device explicitly cleared for injection-free use
        self.serial = serial
        self.added_by = added_by
        self.added_at = datetime.now().isoformat()

    @property
    def key(self) -> str:
        return f"{self.vid}:{self.pid}"

    def to_dict(self) -> dict:
        return {
            "vid":          self.vid,
            "pid":          self.pid,
            "label":        self.label,
            "device_class": self.device_class,
            "trusted_hid":  self.trusted_hid,
            "serial":       self.serial,
            "added_by":     self.added_by,
            "added_at":     self.added_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "WhitelistEntry":
        entry = cls(
            vid=d["vid"],
            pid=d["pid"],
            label=d.get("label", "Unknown"),
            device_class=d.get("device_class"),
            trusted_hid=d.get("trusted_hid", False),
            serial=d.get("serial"),
            added_by=d.get("added_by", "user"),
        )
        entry.added_at = d.get("added_at", entry.added_at)
        return entry


class WhitelistManager:
    """
    Thread-safe USB device whitelist.

    On new device connection, call:
        is_whitelisted(vid, pid)  → bool
        is_trusted_hid(vid, pid)  → bool
        get_risk_level(vid, pid, class_guid) → str
    """

    DEFAULT_FILE = os.path.join(
        os.path.dirname(__file__), "..", "config", "whitelist.json"
    )

    def __init__(self, whitelist_file: Optional[str] = None):
        self._file = whitelist_file or self.DEFAULT_FILE
        self._entries: Dict[str, WhitelistEntry] = {}
        self._lock = threading.RLock()
        self._load()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _load(self) -> None:
        if not os.path.exists(self._file):
            self._seed_defaults()
            return
        try:
            with open(self._file, "r", encoding="utf-8") as f:
                data = json.load(f)
            for item in data.get("devices", []):
                entry = WhitelistEntry.from_dict(item)
                self._entries[entry.key] = entry
        except Exception:
            self._entries = {}

    def _save(self) -> None:
        os.makedirs(os.path.dirname(self._file), exist_ok=True)
        with self._lock:
            data = {"devices": [e.to_dict() for e in self._entries.values()]}
        with open(self._file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def _seed_defaults(self) -> None:
        """Pre-populate with well-known safe VID/PIDs."""
        defaults = [
            WhitelistEntry("046D", "C52B", "Logitech Unifying Receiver", trusted_hid=False, added_by="system"),
            WhitelistEntry("046D", "C534", "Logitech USB Receiver", trusted_hid=False, added_by="system"),
            WhitelistEntry("045E", "0745", "Microsoft USB Keyboard", trusted_hid=True, added_by="system"),
            WhitelistEntry("045E", "0040", "Microsoft USB Mouse", trusted_hid=True, added_by="system"),
            WhitelistEntry("05AC", "024F", "Apple Magic Keyboard", trusted_hid=True, added_by="system"),
        ]
        for e in defaults:
            self._entries[e.key] = e
        self._save()

    # ------------------------------------------------------------------
    # Query API
    # ------------------------------------------------------------------

    def is_whitelisted(self, vid: str, pid: str, serial: Optional[str] = None) -> bool:
        key = f"{vid.upper()}:{pid.upper()}"
        with self._lock:
            if key not in self._entries:
                return False
            entry = self._entries[key]
            # If serial is specified in whitelist, enforce serial match
            if entry.serial and serial and entry.serial != serial:
                return False
            return True

    def is_trusted_hid(self, vid: str, pid: str) -> bool:
        """Returns True only for HID devices explicitly cleared by the user."""
        key = f"{vid.upper()}:{pid.upper()}"
        with self._lock:
            return self._entries.get(key, WhitelistEntry("", "", "")).trusted_hid

    def get_risk_level(
        self, vid: str, pid: str, class_guid: Optional[str] = None
    ) -> Tuple[str, str]:
        """
        Returns (risk_level, reason).
        risk_level: 'SAFE' | 'WARN' | 'HIGH' | 'CRITICAL'
        """
        whitelisted = self.is_whitelisted(vid, pid)

        if whitelisted:
            if class_guid in HIGH_RISK_CLASSES:
                return "WARN", "Whitelisted but is a network/modem class device"
            return "SAFE", "Device is on the approved whitelist"

        if class_guid in HIGH_RISK_CLASSES:
            return "CRITICAL", "Unknown USB network adapter — possible rogue interface"

        if class_guid in HID_CLASSES:
            return "HIGH", "Unknown HID device — possible keyboard/injection attack"

        return "HIGH", "Device not on whitelist"

    # ------------------------------------------------------------------
    # Mutate API
    # ------------------------------------------------------------------

    def add(
        self,
        vid: str,
        pid: str,
        label: str,
        device_class: Optional[str] = None,
        trusted_hid: bool = False,
        serial: Optional[str] = None,
    ) -> WhitelistEntry:
        entry = WhitelistEntry(
            vid, pid, label, device_class, trusted_hid, serial, added_by="user"
        )
        with self._lock:
            self._entries[entry.key] = entry
        self._save()
        return entry

    def remove(self, vid: str, pid: str) -> bool:
        key = f"{vid.upper()}:{pid.upper()}"
        with self._lock:
            if key in self._entries:
                del self._entries[key]
                self._save()
                return True
        return False

    def update_trusted_hid(self, vid: str, pid: str, trusted: bool) -> bool:
        key = f"{vid.upper()}:{pid.upper()}"
        with self._lock:
            if key in self._entries:
                self._entries[key].trusted_hid = trusted
                self._save()
                return True
        return False

    def all_entries(self) -> List[WhitelistEntry]:
        with self._lock:
            return list(self._entries.values())

    def count(self) -> int:
        with self._lock:
            return len(self._entries)
