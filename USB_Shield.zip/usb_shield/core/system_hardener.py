"""
USBShield - System Hardener
============================
Applies registry-level Windows hardening to block entire classes of
USB-based attacks without relying on Windows Defender.

Covers attacks:
  • USB autorun attacks               (attack #8)
  • USB storage-based malware         (attack #6)
  • USB malware/worm propagation      (attack #7)
  • Malicious USB driver installation (attack #15)  ← driver signing policy
"""

import subprocess
import threading
from typing import Dict, Optional

try:
    import winreg
    _WINREG = True
except ImportError:
    _WINREG = False


# ---------------------------------------------------------------------------
# Registry paths and their hardening values
# ---------------------------------------------------------------------------

# Each entry: (hive, key_path, value_name, type, hardened_value, original_placeholder)
# type: 'DWORD' | 'SZ' | 'EXPAND_SZ'
HARDENING_RULES = [
    # ── Autorun / AutoPlay ───────────────────────────────────────────────
    # Disable AutoRun for ALL drive types (0xFF = all 256 drive types)
    (
        "HKLM",
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
        "NoDriveTypeAutoRun",
        "DWORD", 0xFF, None,
    ),
    (
        "HKCU",
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
        "NoDriveTypeAutoRun",
        "DWORD", 0xFF, None,
    ),
    # Disable AutoPlay entirely
    (
        "HKLM",
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
        "NoAutorun",
        "DWORD", 1, None,
    ),
    # ── USB Storage class driver ─────────────────────────────────────────
    # Start=3 (demand, default) | Start=4 (disabled)
    # We write this only if the user enables "block all storage" mode
    # (managed separately via block_usb_storage / unblock_usb_storage)

    # ── Driver installation policy ───────────────────────────────────────
    # Prevent installation of unsigned kernel drivers
    (
        "HKLM",
        r"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity",
        "Enabled",
        "DWORD", 1, None,
    ),
    # Prevent automatic driver installation from Windows Update for unknown USB
    (
        "HKLM",
        r"SOFTWARE\Policies\Microsoft\Windows\DriverSearching",
        "SearchOrderConfig",
        "DWORD", 0, None,     # 0 = never search Windows Update
    ),
    # ── Shell execute restrictions ───────────────────────────────────────
    # Prevent shell from running scripts directly from removable drives
    (
        "HKCU",
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations",
        "DefaultFileTypeRisk",
        "DWORD", 0x6152, None,  # HIGH risk for unknown extensions
    ),
]

USBSTOR_KEY  = r"SYSTEM\CurrentControlSet\Services\USBSTOR"
USBSTOR_VAL  = "Start"
USBSTOR_ON   = 3    # demand start (normal)
USBSTOR_OFF  = 4    # disabled


def _hive(name: str):
    if not _WINREG:
        return None
    return {
        "HKLM": winreg.HKEY_LOCAL_MACHINE,
        "HKCU": winreg.HKEY_CURRENT_USER,
    }.get(name)


def _reg_type(type_str: str):
    if not _WINREG:
        return None
    return {"DWORD": winreg.REG_DWORD, "SZ": winreg.REG_SZ,
            "EXPAND_SZ": winreg.REG_EXPAND_SZ}.get(type_str, winreg.REG_DWORD)


def _read_reg(hive_name: str, key_path: str, value_name: str):
    if not _WINREG:
        return None
    hive = _hive(hive_name)
    if not hive:
        return None
    try:
        with winreg.OpenKey(hive, key_path, 0, winreg.KEY_READ) as k:
            val, _ = winreg.QueryValueEx(k, value_name)
            return val
    except FileNotFoundError:
        return None
    except Exception:
        return None


def _write_reg(hive_name: str, key_path: str, value_name: str,
               type_str: str, value) -> bool:
    if not _WINREG:
        return False
    hive = _hive(hive_name)
    if not hive:
        return False
    try:
        with winreg.CreateKeyEx(
            hive, key_path, 0,
            winreg.KEY_SET_VALUE | winreg.KEY_CREATE_SUB_KEY
        ) as k:
            winreg.SetValueEx(k, value_name, 0, _reg_type(type_str), value)
        return True
    except PermissionError:
        return False
    except Exception:
        return False


# ---------------------------------------------------------------------------
# SystemHardener
# ---------------------------------------------------------------------------

class SystemHardener:
    """
    Applies and reverts registry-based USB attack hardening.

    All write operations require SYSTEM / Administrator privileges.
    """

    def __init__(self, logger):
        self._log = logger
        self._lock = threading.Lock()
        # Store original values so we can revert
        self._originals: Dict[str, object] = {}

        # Track current state
        self._autorun_blocked    = False
        self._storage_blocked    = False
        self._hardening_applied  = False

    # ------------------------------------------------------------------
    # Main hardening operations
    # ------------------------------------------------------------------

    def apply_all(self) -> Dict[str, bool]:
        """Apply all registry hardening rules. Returns {rule_name: success}."""
        results = {}
        with self._lock:
            for rule in HARDENING_RULES:
                hive, path, name, rtype, hard_val, _ = rule
                rule_key = f"{hive}\\{path}\\{name}"

                # Save original
                orig = _read_reg(hive, path, name)
                self._originals[rule_key] = orig

                ok = _write_reg(hive, path, name, rtype, hard_val)
                results[rule_key] = ok

                level = "INFO" if ok else "MEDIUM"
                getattr(self._log, level.lower())(
                    "SystemHardener",
                    f"{'Applied' if ok else 'FAILED'}: {name}",
                    f"{rule_key} = {hard_val}",
                )

            self._autorun_blocked   = True
            self._hardening_applied = True

        return results

    def revert_all(self) -> None:
        """Restore all registry keys to their original values."""
        with self._lock:
            for rule in HARDENING_RULES:
                hive, path, name, rtype, _, _ = rule
                rule_key = f"{hive}\\{path}\\{name}"
                orig = self._originals.get(rule_key)
                if orig is not None:
                    _write_reg(hive, path, name, rtype, orig)
            self._autorun_blocked   = False
            self._hardening_applied = False
            self._log.info(
                "SystemHardener", "Hardening reverted",
                "Registry keys restored to original values",
            )

    # ------------------------------------------------------------------
    # Individual controls
    # ------------------------------------------------------------------

    def disable_autorun(self) -> bool:
        """Disable AutoRun/AutoPlay for all drive types via registry."""
        ok1 = _write_reg(
            "HKLM",
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
            "NoDriveTypeAutoRun", "DWORD", 0xFF,
        )
        ok2 = _write_reg(
            "HKCU",
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
            "NoDriveTypeAutoRun", "DWORD", 0xFF,
        )
        ok3 = _write_reg(
            "HKLM",
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
            "NoAutorun", "DWORD", 1,
        )
        success = ok1 or ok2 or ok3
        if success:
            self._autorun_blocked = True
            self._log.info("SystemHardener", "AutoRun disabled",
                           "NoDriveTypeAutoRun=0xFF applied to HKLM and HKCU")
        else:
            self._log.medium("SystemHardener", "AutoRun disable failed",
                              "Registry write failed — need Administrator rights")
        return success

    def enable_autorun(self) -> bool:
        """Re-enable AutoRun (removes the policy restriction)."""
        ok1 = _write_reg(
            "HKLM",
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
            "NoDriveTypeAutoRun", "DWORD", 0x91,   # disable removable/network only
        )
        ok2 = _write_reg(
            "HKCU",
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
            "NoDriveTypeAutoRun", "DWORD", 0x91,
        )
        if ok1 or ok2:
            self._autorun_blocked = False
        return ok1 or ok2

    def block_usb_storage(self) -> bool:
        """
        Block ALL USB storage devices by disabling the USBSTOR driver.
        This prevents USB flash drives, external HDDs, etc. from mounting.
        """
        ok = _write_reg("HKLM", USBSTOR_KEY, USBSTOR_VAL, "DWORD", USBSTOR_OFF)
        if ok:
            self._storage_blocked = True
            self._log.high(
                "SystemHardener",
                "USB storage BLOCKED",
                "USBSTOR Start=4 — USB drives will not mount until re-enabled",
            )
        else:
            self._log.medium(
                "SystemHardener", "USB storage block failed",
                "Could not write USBSTOR registry key — need Administrator",
            )
        return ok

    def unblock_usb_storage(self) -> bool:
        """Re-enable USB storage (USBSTOR Start=3)."""
        ok = _write_reg("HKLM", USBSTOR_KEY, USBSTOR_VAL, "DWORD", USBSTOR_ON)
        if ok:
            self._storage_blocked = False
            self._log.info("SystemHardener", "USB storage re-enabled",
                           "USBSTOR Start=3")
        return ok

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def get_status(self) -> Dict[str, object]:
        autorun_val = _read_reg(
            "HKLM",
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
            "NoDriveTypeAutoRun",
        )
        storage_val = _read_reg("HKLM", USBSTOR_KEY, USBSTOR_VAL)
        return {
            "autorun_blocked":   autorun_val == 0xFF,
            "storage_blocked":   storage_val == USBSTOR_OFF,
            "hardening_applied": self._hardening_applied,
            "autorun_reg_value": autorun_val,
            "usbstor_start":     storage_val,
        }

    def is_admin(self) -> bool:
        """Check whether the current process has Administrator rights."""
        try:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False

    # ------------------------------------------------------------------
    # One-shot PowerShell hardening (fallback if registry write fails)
    # ------------------------------------------------------------------

    def apply_powershell_hardening(self) -> None:
        """
        Fallback: use PowerShell to set same policies in case direct
        registry writes are blocked by Group Policy.
        """
        commands = [
            # Disable AutoPlay for all drives
            "Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer' "
            "-Name NoDriveTypeAutoRun -Value 0xFF -Type DWord -Force",
            # Disable Windows AutoPlay service
            "Stop-Service -Name ShellHWDetection -ErrorAction SilentlyContinue; "
            "Set-Service  -Name ShellHWDetection -StartupType Disabled -ErrorAction SilentlyContinue",
        ]
        for cmd in commands:
            try:
                subprocess.run(
                    ["powershell", "-NonInteractive", "-Command", cmd],
                    capture_output=True, timeout=10,
                )
            except Exception:
                pass
