"""
USBShield - Threat Logger
Handles all event and threat logging with severity levels, persistence,
and real-time callback notification for the GUI.
"""

import os
import json
import logging
import threading
from datetime import datetime
from enum import Enum
from typing import Callable, List, Optional


class Severity(Enum):
    INFO    = "INFO"
    LOW     = "LOW"
    MEDIUM  = "MEDIUM"
    HIGH    = "HIGH"
    CRITICAL = "CRITICAL"


SEVERITY_ORDER = {
    Severity.INFO: 0,
    Severity.LOW: 1,
    Severity.MEDIUM: 2,
    Severity.HIGH: 3,
    Severity.CRITICAL: 4,
}

SEVERITY_COLORS = {
    Severity.INFO:     "#7EC8E3",
    Severity.LOW:      "#A8E6CF",
    Severity.MEDIUM:   "#FFD700",
    Severity.HIGH:     "#FF8C00",
    Severity.CRITICAL: "#FF3B30",
}


class ThreatEvent:
    """Represents a single threat or informational event."""

    def __init__(
        self,
        category: str,
        severity: Severity,
        title: str,
        description: str,
        device_id: Optional[str] = None,
        extra: Optional[dict] = None,
    ):
        self.timestamp = datetime.now()
        self.category = category
        self.severity = severity
        self.title = title
        self.description = description
        self.device_id = device_id
        self.extra = extra or {}

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp.isoformat(),
            "category":  self.category,
            "severity":  self.severity.value,
            "title":     self.title,
            "description": self.description,
            "device_id": self.device_id,
            "extra":     self.extra,
        }

    def to_log_line(self) -> str:
        ts = self.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        return (
            f"[{ts}] [{self.severity.value:8s}] [{self.category:20s}] "
            f"{self.title} — {self.description}"
        )


class ThreatLogger:
    """
    Central logging hub for USBShield.

    - Writes to a rotating daily log file
    - Keeps an in-memory ring buffer for the GUI
    - Fires registered callbacks on new events (GUI updates)
    - Supports export to JSON
    """

    MAX_MEMORY_EVENTS = 2000

    def __init__(self, log_dir: str = "logs"):
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)

        self._events: List[ThreatEvent] = []
        self._callbacks: List[Callable[[ThreatEvent], None]] = []
        self._lock = threading.Lock()

        # Setup Python logging to file
        log_file = os.path.join(
            log_dir,
            f"usb_shield_{datetime.now().strftime('%Y%m%d')}.log",
        )
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(message)s",
            handlers=[
                logging.FileHandler(log_file, encoding="utf-8"),
            ],
        )
        self._file_logger = logging.getLogger("usb_shield")

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register_callback(self, cb: Callable[[ThreatEvent], None]) -> None:
        """Register a function to be called whenever a new event is logged."""
        with self._lock:
            self._callbacks.append(cb)

    def unregister_callback(self, cb: Callable[[ThreatEvent], None]) -> None:
        with self._lock:
            self._callbacks = [c for c in self._callbacks if c is not cb]

    # ------------------------------------------------------------------
    # Logging helpers
    # ------------------------------------------------------------------

    def log(
        self,
        category: str,
        severity: Severity,
        title: str,
        description: str,
        device_id: Optional[str] = None,
        extra: Optional[dict] = None,
    ) -> ThreatEvent:
        event = ThreatEvent(category, severity, title, description, device_id, extra)

        with self._lock:
            self._events.append(event)
            if len(self._events) > self.MAX_MEMORY_EVENTS:
                self._events = self._events[-self.MAX_MEMORY_EVENTS:]
            callbacks = list(self._callbacks)

        # Write to file outside lock
        self._file_logger.info(event.to_log_line())

        # Fire callbacks (outside lock to avoid deadlock)
        for cb in callbacks:
            try:
                cb(event)
            except Exception:
                pass

        return event

    # Convenience wrappers
    def info(self, category, title, description, **kw):
        return self.log(category, Severity.INFO, title, description, **kw)

    def low(self, category, title, description, **kw):
        return self.log(category, Severity.LOW, title, description, **kw)

    def medium(self, category, title, description, **kw):
        return self.log(category, Severity.MEDIUM, title, description, **kw)

    def high(self, category, title, description, **kw):
        return self.log(category, Severity.HIGH, title, description, **kw)

    def critical(self, category, title, description, **kw):
        return self.log(category, Severity.CRITICAL, title, description, **kw)

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def get_events(
        self,
        min_severity: Severity = Severity.INFO,
        category: Optional[str] = None,
        limit: int = 500,
    ) -> List[ThreatEvent]:
        min_order = SEVERITY_ORDER[min_severity]
        with self._lock:
            result = [
                e for e in self._events
                if SEVERITY_ORDER[e.severity] >= min_order
                and (category is None or e.category == category)
            ]
        return result[-limit:]

    def get_threat_count(self, min_severity: Severity = Severity.MEDIUM) -> int:
        min_order = SEVERITY_ORDER[min_severity]
        with self._lock:
            return sum(
                1 for e in self._events
                if SEVERITY_ORDER[e.severity] >= min_order
            )

    def export_json(self, filepath: str) -> None:
        with self._lock:
            data = [e.to_dict() for e in self._events]
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def clear(self) -> None:
        with self._lock:
            self._events.clear()
