"""
USBShield - Device Monitor  (v2 — fixed)
=========================================
Real-time USB device plug/unplug detection via WMI with:
  • Session counters (total seen / blocked) for the dashboard
  • Full device info embedded in every event's extras dict
    so whitelist/block handlers never need a secondary lookup
  • enumerate_current_devices() called at start() so the device
    panel is populated immediately on launch, without waiting for
    a plug event

Covers attacks: #1-#5, #14, #15
"""

import re
import subprocess
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, Dict, List, Optional, Set

try:
    import pythoncom, wmi
    _WMI_AVAILABLE = True
except ImportError:
    _WMI_AVAILABLE = False

try:
    import winreg
    _WINREG_AVAILABLE = True
except ImportError:
    _WINREG_AVAILABLE = False


KNOWN_ATTACK_DEVICES: Dict[str, str] = {
    "F000:0002": "Hak5 Rubber Ducky",
    "F000:0014": "Hak5 Bash Bunny",
    "F000:0012": "Hak5 LAN Turtle",
    "F000:0010": "Hak5 Key Croc",
    "1209:2900": "Digispark ATtiny85 (HID inject board)",
    "2341:0043": "Arduino Uno (HID inject repurpose)",
    "16D0:0753": "Cactus WHID / MottePlusBoard",
    "1B4F:9207": "SparkFun Pro Micro (HID inject)",
    "239A:0015": "Adafruit Trinket M0",
    "239A:001B": "Adafruit Circuit Playground Express",
    "03EB:2042": "Atmel HID demo kit",
    "04B4:0002": "Cypress HID inject demo",
    "1781:0C9F": "USBtinyISP reflashed as HID",
}

CLASS_HID      = "{745A17A0-74D3-11D0-B6FE-00A0C90F57DA}"
CLASS_KEYBOARD = "{4D36E96B-E325-11CE-BFC1-08002BE10318}"
CLASS_MOUSE    = "{4D36E96F-E325-11CE-BFC1-08002BE10318}"
CLASS_NET      = "{4D36E972-E325-11CE-BFC1-08002BE10318}"
CLASS_DISK     = "{4D36E967-E325-11CE-BFC1-08002BE10318}"
CLASS_WPD      = "{EEC5AD98-8080-425F-922A-DABF3DE3F69A}"


@dataclass
class USBDeviceInfo:
    instance_id:   str
    pnp_device_id: str
    name:          str
    description:   str
    manufacturer:  str
    device_class:  str
    class_guid:    Optional[str]
    vid:           str = ""
    pid:           str = ""
    serial:        str = ""
    connected_at:  datetime = field(default_factory=datetime.now)
    is_blocked:    bool = False

    @property
    def vid_pid_key(self) -> str:
        return f"{self.vid}:{self.pid}"

    @property
    def is_hid_class(self) -> bool:
        if not self.class_guid:
            return False
        return self.class_guid.upper() in {
            CLASS_HID.upper(), CLASS_KEYBOARD.upper(), CLASS_MOUSE.upper()
        }

    @property
    def is_network_class(self) -> bool:
        return bool(self.class_guid) and self.class_guid.upper() == CLASS_NET.upper()

    @property
    def is_storage_class(self) -> bool:
        if not self.class_guid:
            return False
        return self.class_guid.upper() in {CLASS_DISK.upper(), CLASS_WPD.upper()}


def parse_vid_pid_serial(pnp_id: str):
    vid = pid = serial = ""
    m = re.search(r"VID_([0-9A-Fa-f]{4})", pnp_id)
    if m:
        vid = m.group(1).upper()
    m = re.search(r"PID_([0-9A-Fa-f]{4})", pnp_id)
    if m:
        pid = m.group(1).upper()
    parts = pnp_id.split("\\")
    if len(parts) >= 3:
        raw = parts[2]
        if not raw.startswith("5&") and len(raw) > 4:
            serial = raw
    return vid, pid, serial


class DeviceMonitor:
    """
    Monitors USB device connection/disconnection events.

    Session counters available for the GUI dashboard:
        get_session_total()    — total devices connected this session
        get_blocked_count()    — how many were blocked
    """

    POLL_INTERVAL = 1

    def __init__(self, whitelist_manager, logger):
        self._wl   = whitelist_manager
        self._log  = logger
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Live connected devices
        self._connected: Dict[str, USBDeviceInfo] = {}
        self._lock = threading.Lock()

        # Session-wide counters (never reset until app restarts)
        self._session_total   = 0
        self._blocked_count   = 0

        # Session allow-list: VID:PID pairs allowed "just once" by the user
        self._session_allowed: Set[str] = set()

        # Callbacks — set externally
        self.on_device_connected:    Optional[Callable] = None  # (dev, risk, reason)
        self.on_device_disconnected: Optional[Callable] = None  # (dev,)

        # Settings
        self.auto_block_unknown               = False
        self.auto_block_known_attack_devices  = True

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._running:
            return
        self._running = True

        # Pre-populate with currently connected devices so the device
        # panel is not empty on first launch.
        self._pre_populate()

        self._thread = threading.Thread(
            target=self._monitor_loop, daemon=True, name="DeviceMonitor"
        )
        self._thread.start()
        self._log.info("DeviceMonitor", "Device monitor started",
                       "Watching for USB connection events")

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _pre_populate(self) -> None:
        """Enumerate devices already connected before USBShield started."""
        devs = self.enumerate_current_devices()
        with self._lock:
            for d in devs:
                if d.instance_id not in self._connected:
                    self._connected[d.instance_id] = d
        self._log.info("DeviceMonitor", f"Found {len(devs)} pre-existing USB devices",
                       "Device panel pre-populated")

    # ------------------------------------------------------------------
    # WMI monitoring loop
    # ------------------------------------------------------------------

    def _monitor_loop(self) -> None:
        if not _WMI_AVAILABLE:
            self._log.medium("DeviceMonitor", "WMI unavailable",
                             "Stub mode — install pywin32+wmi on Windows for live monitoring")
            while self._running:
                time.sleep(1)
            return

        pythoncom.CoInitialize()
        # Keep references so we can explicitly delete before CoUninitialize.
        # Not doing this causes "Win32 exception occurred releasing IUnknown"
        # because CoUninitialize frees the apartment while live COM objects
        # are still referenced by Python's garbage collector.
        c = None
        create_w = None
        delete_w = None
        try:
            c = wmi.WMI()
            wql_c = ("SELECT * FROM __InstanceCreationEvent WITHIN 2 "
                     "WHERE TargetInstance ISA 'Win32_PnPEntity' "
                     "AND TargetInstance.PNPDeviceID LIKE 'USB%'")
            wql_d = ("SELECT * FROM __InstanceDeletionEvent WITHIN 2 "
                     "WHERE TargetInstance ISA 'Win32_PnPEntity' "
                     "AND TargetInstance.PNPDeviceID LIKE 'USB%'")
            create_w = c.ExecNotificationQuery(wql_c)
            delete_w = c.ExecNotificationQuery(wql_d)
            while self._running:
                self._poll(create_w, connected=True)
                self._poll(delete_w, connected=False)
                time.sleep(self.POLL_INTERVAL)
        except Exception as exc:
            self._log.high("DeviceMonitor", "WMI error", str(exc))
        finally:
            # Release every COM reference in reverse order of creation,
            # then force a GC cycle before uninitialising the COM apartment.
            # This is the only reliable way to suppress the
            #   "Win32 exception occurred releasing IUnknown"
            # messages that pythoncom prints when its apartment shuts down
            # while Python's GC still holds live COM wrapper objects.
            try:
                del delete_w
            except Exception:
                pass
            try:
                del create_w
            except Exception:
                pass
            try:
                del c
            except Exception:
                pass
            try:
                import gc as _gc
                _gc.collect()
                _gc.collect()   # two passes: first breaks cycles, second frees them
            except Exception:
                pass

            # CoUninitialize may still emit a harmless Win32 message to the
            # C-level stderr handle.  Redirect file-descriptor 2 briefly to
            # swallow it so the console stays clean.
            try:
                import os as _os
                import sys as _sys
                _devnull_fd = _os.open(_os.devnull, _os.O_WRONLY)
                _old_fd2    = _os.dup(2)
                _os.dup2(_devnull_fd, 2)
                try:
                    pythoncom.CoUninitialize()
                finally:
                    _os.dup2(_old_fd2, 2)
                    _os.close(_old_fd2)
                    _os.close(_devnull_fd)
            except Exception:
                try:
                    pythoncom.CoUninitialize()
                except Exception:
                    pass

    def _poll(self, watcher, connected: bool) -> None:
        try:
            event = watcher.NextEvent(TimeoutMs=100)
            info  = self._build_info(event.TargetInstance)
            if connected:
                self._handle_connection(info)
            else:
                self._handle_disconnection(info)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Device info
    # ------------------------------------------------------------------

    def _build_info(self, pnp) -> USBDeviceInfo:
        pnp_id = getattr(pnp, "PNPDeviceID", "") or ""
        vid, pid, serial = parse_vid_pid_serial(pnp_id)
        return USBDeviceInfo(
            instance_id   = pnp_id,
            pnp_device_id = pnp_id,
            name          = getattr(pnp, "Name", "Unknown") or "Unknown",
            description   = getattr(pnp, "Description", "") or "",
            manufacturer  = getattr(pnp, "Manufacturer", "Unknown") or "Unknown",
            device_class  = getattr(pnp, "PNPClass", "") or "",
            class_guid    = getattr(pnp, "ClassGuid", None),
            vid=vid, pid=pid, serial=serial,
        )

    # ------------------------------------------------------------------
    # Connection handlers
    # ------------------------------------------------------------------

    def _handle_connection(self, info: USBDeviceInfo) -> None:
        with self._lock:
            self._connected[info.instance_id] = info
            self._session_total += 1

        risk, reason = self._assess_risk(info)

        # Auto-block
        if risk == "CRITICAL" and self.auto_block_known_attack_devices:
            self.disable_device(info.instance_id)
            info.is_blocked = True
        elif risk == "HIGH" and self.auto_block_unknown:
            self.disable_device(info.instance_id)
            info.is_blocked = True

        from core.threat_logger import Severity
        sev_map = {"SAFE": Severity.INFO, "LOW": Severity.LOW,
                   "MEDIUM": Severity.MEDIUM, "HIGH": Severity.HIGH,
                   "CRITICAL": Severity.CRITICAL}

        # Embed FULL device info in extras so handlers never need a lookup
        extras = {
            "vid":          info.vid,
            "pid":          info.pid,
            "serial":       info.serial,
            "device_name":  info.name,
            "manufacturer": info.manufacturer,
            "class":        info.device_class,
            "instance_id":  info.instance_id,
            "blocked":      info.is_blocked,
            "risk":         risk,
        }

        self._log.log(
            "DeviceMonitor",
            sev_map.get(risk, Severity.HIGH),
            f"USB device connected — {risk}",
            f"{info.name} [{info.vid}:{info.pid}]  {reason}",
            device_id=info.instance_id,
            extra=extras,
        )

        if self.on_device_connected:
            self.on_device_connected(info, risk, reason)

    def _handle_disconnection(self, info: USBDeviceInfo) -> None:
        with self._lock:
            self._connected.pop(info.instance_id, None)
        self._log.info("DeviceMonitor", "USB device disconnected",
                       f"{info.name} [{info.vid}:{info.pid}]",
                       device_id=info.instance_id)
        if self.on_device_disconnected:
            self.on_device_disconnected(info)

    # ------------------------------------------------------------------
    # Risk assessment
    # ------------------------------------------------------------------

    def _assess_risk(self, info: USBDeviceInfo):
        vid_pid = info.vid_pid_key

        if vid_pid in KNOWN_ATTACK_DEVICES:
            return "CRITICAL", f"KNOWN ATTACK DEVICE: {KNOWN_ATTACK_DEVICES[vid_pid]}"

        if vid_pid in self._session_allowed:
            return "SAFE", "Allowed for this session by user"

        if self._wl.is_whitelisted(info.vid, info.pid, info.serial):
            return "SAFE", "Device is on the approved whitelist"

        if info.is_network_class:
            return "CRITICAL", "Unknown USB network adapter — possible rogue interface"

        if info.is_hid_class:
            return "HIGH", "Unknown HID device — possible keyboard injection tool"

        return "HIGH", "Device not on approved whitelist"

    # ------------------------------------------------------------------
    # Device control
    # ------------------------------------------------------------------

    def disable_device(self, instance_id: str) -> bool:
        """Disable a USB device using PowerShell Disable-PnpDevice."""
        try:
            safe_id = instance_id.replace("'", "''")
            cmd = (f"Disable-PnpDevice -InstanceId '{safe_id}' "
                   f"-Confirm:$false -ErrorAction Stop")
            result = subprocess.run(
                ["powershell", "-NonInteractive", "-Command", cmd],
                capture_output=True, text=True, timeout=10,
            )
            success = result.returncode == 0
            if success:
                with self._lock:
                    if instance_id in self._connected:
                        self._connected[instance_id].is_blocked = True
                    self._blocked_count += 1
                self._log.high("DeviceMonitor", "Device BLOCKED",
                               f"Disabled: {instance_id}", device_id=instance_id)
            else:
                self._log.medium("DeviceMonitor", "Block failed",
                                 result.stderr.strip()[:200], device_id=instance_id)
            return success
        except Exception as exc:
            self._log.medium("DeviceMonitor", "Block error", str(exc))
            return False

    def enable_device(self, instance_id: str) -> bool:
        try:
            safe_id = instance_id.replace("'", "''")
            cmd = (f"Enable-PnpDevice -InstanceId '{safe_id}' "
                   f"-Confirm:$false -ErrorAction Stop")
            result = subprocess.run(
                ["powershell", "-NonInteractive", "-Command", cmd],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                with self._lock:
                    if instance_id in self._connected:
                        self._connected[instance_id].is_blocked = False
            return result.returncode == 0
        except Exception:
            return False

    def allow_once(self, vid: str, pid: str) -> None:
        """Add VID:PID to the session allow-list — suppresses re-alert this session."""
        self._session_allowed.add(f"{vid.upper()}:{pid.upper()}")

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_connected_devices(self) -> List[USBDeviceInfo]:
        with self._lock:
            return list(self._connected.values())

    def get_device(self, instance_id: str) -> Optional[USBDeviceInfo]:
        with self._lock:
            return self._connected.get(instance_id)

    def get_session_total(self) -> int:
        return self._session_total

    def get_blocked_count(self) -> int:
        return self._blocked_count

    # ------------------------------------------------------------------
    # Static enumeration (WMI one-shot)
    # ------------------------------------------------------------------

    @staticmethod
    def enumerate_current_devices() -> List[USBDeviceInfo]:
        devices = []
        if not _WMI_AVAILABLE:
            return devices
        try:
            pythoncom.CoInitialize()
            c = wmi.WMI()
            for pnp in c.Win32_PnPEntity():
                pnp_id = getattr(pnp, "PNPDeviceID", "") or ""
                if not pnp_id.upper().startswith("USB"):
                    continue
                vid, pid, serial = parse_vid_pid_serial(pnp_id)
                info = USBDeviceInfo(
                    instance_id=pnp_id, pnp_device_id=pnp_id,
                    name=getattr(pnp, "Name", "Unknown") or "Unknown",
                    description=getattr(pnp, "Description", "") or "",
                    manufacturer=getattr(pnp, "Manufacturer", "Unknown") or "Unknown",
                    device_class=getattr(pnp, "PNPClass", "") or "",
                    class_guid=getattr(pnp, "ClassGuid", None),
                    vid=vid, pid=pid, serial=serial,
                )
                devices.append(info)
        except Exception:
            pass
        finally:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass
        return devices
