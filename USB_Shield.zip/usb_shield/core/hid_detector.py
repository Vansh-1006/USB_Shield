"""
USBShield - HID Injection Detector  (v2 — fixed)
==================================================
FIXED ISSUES:
  • hMod=NULL for WH_KEYBOARD_LL (Microsoft requirement — was broken before)
  • Proper ctypes argtypes/restype declarations (prevents 64-bit corruption)
  • GetMessageW message loop with PostThreadMessageW stop (no more missed callbacks)
  • BURST DETECTION: 10 keys in 150ms → CRITICAL immediately, no cooldown
    (catches Rubber Ducky payloads that complete in <1 second)
  • Behavioral detection continues even for whitelisted devices

Covers attacks: #1 #2 #3 #4 #5
"""

import ctypes
import ctypes.wintypes as wintypes
import threading
import time
from collections import deque
from datetime import datetime
from typing import Callable, Deque, List, Optional

# ── Windows constants ────────────────────────────────────────────────────
WH_KEYBOARD_LL  = 13
WM_KEYDOWN      = 0x0100
WM_SYSKEYDOWN   = 0x0104
WM_QUIT         = 0x0012
HC_ACTION       = 0

# ── Detection thresholds ────────────────────────────────────────────────
HUMAN_MAX_KPS        = 15    # max sustainable keystrokes/sec for fastest human typists
WARNING_KPS          = 25
INJECTION_KPS        = 60    # high-confidence machine injection
VARIANCE_THRESHOLD   = 8.0   # ms — below this = machine-perfect timing
MIN_BURST_LENGTH     = 8     # min keys in 1-sec window before analysis
WINDOW_SECONDS       = 1.0

# ── Burst detection ──────────────────────────────────────────────────────
# Raised from 10→15 keys and tightened to 100ms to eliminate false positives
# from rapid typing, auto-repeat (holding Delete/Backspace), and copy-paste
# shortcuts.  Rubber Ducky at 200 kps still fires (15 keys in 75 ms).
BURST_COUNT = 15
BURST_MS    = 100

# ── VK codes that represent actual typed characters ──────────────────────
# Excludes: Ctrl(0x11) Alt(0x12) Shift(0x10) Win(0x5B/5C) CapsLock(0x14)
#           Delete(0x2E) Backspace(0x08) Arrow/Nav keys F1-F24 Ins/PgUp etc.
# Only counts keys that produce printable output — exactly what Rubber Ducky
# sends to execute payloads.  Holding Delete to clear a field no longer
# triggers the detector because 0x2E is not in this set.
_TYPING_VK: frozenset = frozenset(
    list(range(0x30, 0x5B))   # 0-9, A-Z
    + list(range(0x60, 0x70)) # Numpad 0-9, *, +, Enter, -, ., /
    + [
        0x20,  # Space
        0x0D,  # Enter (main keyboard)
        0x09,  # Tab
        0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF, 0xC0,  # ; = , - . / `
        0xDB, 0xDC, 0xDD, 0xDE,                      # [ \ ] '
    ]
)


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode",      wintypes.DWORD),
        ("scanCode",    wintypes.DWORD),
        ("flags",       wintypes.DWORD),
        ("time",        wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]


class InjectionEvent:
    def __init__(self, kps: float, variance_ms: float,
                 confidence: int, burst_length: int, burst_mode: bool = False):
        self.timestamp    = datetime.now()
        self.kps          = round(kps, 1)
        self.variance_ms  = round(variance_ms, 2)
        self.confidence   = confidence
        self.burst_length = burst_length
        self.burst_mode   = burst_mode    # True = caught by burst detector

    def summary(self) -> str:
        mode = "BURST-DETECT" if self.burst_mode else "rate-analysis"
        return (f"Keystroke injection ({mode}) — "
                f"{self.kps} keys/sec, variance {self.variance_ms} ms, "
                f"confidence {self.confidence}%, burst {self.burst_length} keys")


class HIDInjectionDetector:
    """
    Installs WH_KEYBOARD_LL hook and analyses keystroke timing.
    Fires on_injection_detected for every confirmed injection event.
    Monitoring continues even if the device is on the whitelist.
    """

    ALERT_COOLDOWN = 5.0   # seconds between repeated alerts

    def __init__(self, logger):
        self._log     = logger
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._thread_id: int = 0
        self._hook_id = None

        self._timestamps: Deque[int] = deque()
        self._ts_lock = threading.Lock()

        self.on_injection_detected: Optional[Callable[[InjectionEvent], None]] = None

        self._last_alert_time = 0.0
        self._monitoring_active = False
        self._hook_proc_ref = None  # keep HOOKPROC alive

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._hook_thread, daemon=True, name="HIDDetector"
        )
        self._thread.start()
        self._log.info("HIDDetector", "HID injection monitor started",
                       f"Burst threshold: {BURST_COUNT} keys/{BURST_MS}ms  "
                       f"Rate threshold: {INJECTION_KPS} kps")

    def stop(self) -> None:
        self._running = False
        self._monitoring_active = False
        # Wake the blocking GetMessageW so the thread can exit
        if self._thread_id:
            try:
                ctypes.windll.user32.PostThreadMessageW(
                    self._thread_id, WM_QUIT, 0, 0
                )
            except Exception:
                pass

    def is_active(self) -> bool:
        return self._running and self._monitoring_active

    # ------------------------------------------------------------------
    # Hook thread
    # ------------------------------------------------------------------

    def _hook_thread(self) -> None:
        try:
            user32   = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32

            # ── Declare return types / argtypes to avoid 64-bit corruption ──
            LRESULT  = ctypes.c_long
            HOOKPROC = ctypes.WINFUNCTYPE(
                LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM
            )

            user32.SetWindowsHookExW.restype  = ctypes.c_void_p
            user32.SetWindowsHookExW.argtypes = [
                ctypes.c_int, HOOKPROC, ctypes.c_void_p, wintypes.DWORD
            ]
            user32.CallNextHookEx.restype  = LRESULT
            user32.CallNextHookEx.argtypes = [
                ctypes.c_void_p, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM
            ]
            user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
            user32.GetMessageW.argtypes = [
                ctypes.POINTER(wintypes.MSG), wintypes.HWND,
                wintypes.UINT, wintypes.UINT
            ]

            # Save thread ID so stop() can post WM_QUIT
            self._thread_id = kernel32.GetCurrentThreadId()

            def _handler(nCode: int, wParam: int, lParam: int) -> int:
                if nCode == HC_ACTION and wParam in (WM_KEYDOWN, WM_SYSKEYDOWN):
                    kb = ctypes.cast(
                        lParam, ctypes.POINTER(KBDLLHOOKSTRUCT)
                    ).contents
                    # Only count printable/typing VK codes.
                    # Excludes Ctrl, Alt, Shift, Delete, Backspace, F-keys,
                    # arrow keys, etc. so that keyboard shortcuts and holding
                    # Delete cannot trigger injection detection.
                    if kb.vkCode in _TYPING_VK:
                        self._record_keystroke(kb.time)
                return user32.CallNextHookEx(self._hook_id, nCode, wParam, lParam)

            self._hook_proc_ref = HOOKPROC(_handler)

            # ── CRITICAL FIX: hMod MUST be NULL for WH_KEYBOARD_LL ──────────
            # (Passing GetModuleHandleW silently prevents hook installation
            #  on many Windows versions)
            self._hook_id = user32.SetWindowsHookExW(
                WH_KEYBOARD_LL,
                self._hook_proc_ref,
                None,    # hMod = NULL  ← required for low-level hooks
                0,       # dwThreadId = 0 = system-wide
            )

            if not self._hook_id:
                err = kernel32.GetLastError()
                self._log.medium("HIDDetector", "Hook install failed",
                                 f"SetWindowsHookExW returned NULL (error {err}). "
                                 "Run USBShield as Administrator.")
                return

            self._monitoring_active = True
            self._log.info("HIDDetector", "Keyboard hook installed",
                           "System-wide WH_KEYBOARD_LL hook active")

            # ── FIXED message loop: GetMessageW blocks until message arrives ─
            # This is more reliable than PeekMessageW + sleep which can
            # miss callbacks under heavy system load.
            msg = wintypes.MSG()
            while self._running:
                ret = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if ret == 0 or ret == -1:
                    break
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))

        except OSError:
            self._stub_mode()
        finally:
            if self._hook_id:
                try:
                    ctypes.windll.user32.UnhookWindowsHookEx(self._hook_id)
                except Exception:
                    pass
            self._monitoring_active = False

    def _stub_mode(self) -> None:
        self._log.info("HIDDetector", "Stub mode (non-Windows)",
                       "Low-level keyboard hook unavailable.")
        while self._running:
            time.sleep(1)

    # ------------------------------------------------------------------
    # Keystroke recording and analysis
    # ------------------------------------------------------------------

    def _record_keystroke(self, tick_ms: int) -> None:
        with self._ts_lock:
            self._timestamps.append(tick_ms)
            cutoff = tick_ms - int(WINDOW_SECONDS * 1000)
            while self._timestamps and self._timestamps[0] < cutoff:
                self._timestamps.popleft()
            snapshot = list(self._timestamps)

        # ── BURST CHECK (no cooldown — immediate CRITICAL) ───────────────
        if len(snapshot) >= BURST_COUNT:
            burst_window = snapshot[-1] - snapshot[-BURST_COUNT]
            if 0 < burst_window <= BURST_MS:
                kps = (BURST_COUNT - 1) / (burst_window / 1000.0)
                ev  = InjectionEvent(
                    kps=kps, variance_ms=0.0,
                    confidence=100, burst_length=BURST_COUNT,
                    burst_mode=True,
                )
                self._log.critical(
                    "HIDDetector",
                    "HID Keystroke Injection — BURST DETECTED",
                    ev.summary(),
                    extra={"kps": ev.kps, "confidence": 100,
                           "burst_mode": True, "burst_count": BURST_COUNT,
                           "burst_ms": burst_window},
                )
                if self.on_injection_detected:
                    self.on_injection_detected(ev)
                # Clear timestamps after burst fire to avoid re-triggering
                with self._ts_lock:
                    self._timestamps.clear()
                return

        # ── SLIDING WINDOW ANALYSIS ───────────────────────────────────────
        if len(snapshot) >= MIN_BURST_LENGTH:
            self._analyse(snapshot)

    def _analyse(self, timestamps: List[int]) -> None:
        n = len(timestamps)
        if n < 2:
            return

        window_ms = timestamps[-1] - timestamps[0]
        kps = (n - 1) / (window_ms / 1000.0) if window_ms > 0 else 999.0

        intervals = [timestamps[i] - timestamps[i-1] for i in range(1, n)]
        mean_iv   = sum(intervals) / len(intervals)
        std_dev   = (sum((x - mean_iv)**2 for x in intervals) / len(intervals)) ** 0.5

        confidence = self._compute_confidence(kps, std_dev)

        if confidence >= 50:
            now = time.monotonic()
            if now - self._last_alert_time < self.ALERT_COOLDOWN:
                return
            self._last_alert_time = now

            ev = InjectionEvent(
                kps=kps, variance_ms=std_dev,
                confidence=confidence, burst_length=n,
            )
            self._log.critical(
                "HIDDetector",
                "HID Keystroke Injection Detected",
                ev.summary(),
                extra={"kps": ev.kps, "confidence": ev.confidence,
                       "variance_ms": ev.variance_ms, "burst_length": n,
                       "burst_mode": False},
            )
            if self.on_injection_detected:
                self.on_injection_detected(ev)

    @staticmethod
    def _compute_confidence(kps: float, std_dev_ms: float) -> int:
        # Speed score (0-60)
        if kps <= HUMAN_MAX_KPS:
            speed_score = 0
        elif kps >= INJECTION_KPS:
            speed_score = 60
        else:
            speed_score = int(60 * (kps - HUMAN_MAX_KPS) / (INJECTION_KPS - HUMAN_MAX_KPS))

        # Uniformity score (0-40)
        if std_dev_ms >= 40:
            uniform_score = 0
        elif std_dev_ms <= VARIANCE_THRESHOLD:
            uniform_score = 40
        else:
            uniform_score = int(40 * (40 - std_dev_ms) / (40 - VARIANCE_THRESHOLD))

        return min(100, speed_score + uniform_score)

    # ------------------------------------------------------------------
    # Simulation (testing only)
    # ------------------------------------------------------------------

    def simulate_injection(self) -> None:
        """Testing only — injects 80 synthetic keystrokes at 200 kps."""
        now_ms = int(time.time() * 1000)
        fake   = [now_ms + i * 5 for i in range(80)]  # 80 keys @ 5 ms = 200 kps
        with self._ts_lock:
            self._timestamps.extend(fake)
        # Always expire the cooldown so this test helper reliably fires,
        # regardless of how long the process has been running.
        self._last_alert_time = time.monotonic() - (self.ALERT_COOLDOWN + 1)
        self._analyse(fake)
