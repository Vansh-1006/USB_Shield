"""
USBShield - Driver Monitor & Network Guard
==========================================
Two protection modules in one file:

DriverMonitor  — watches Windows for new driver installations,
                 alerts on unsigned or unknown package sources.
                 Covers attack #15: Malicious/unauthorized USB driver installation

NetworkGuard   — detects rogue USB network adapters (RNDIS, CDC-ECM, etc.)
                 Covers attack #14: Rogue/unauthorized USB network interfaces
"""

import subprocess
import threading
import time
from datetime import datetime
from typing import Callable, Dict, List, Optional, Set

try:
    import pythoncom
    import wmi
    _WMI = True
except ImportError:
    _WMI = False

try:
    import psutil
    _PSUTIL = True
except ImportError:
    _PSUTIL = False


# ===========================================================================
# DriverMonitor
# ===========================================================================

# Registry paths where new drivers are registered
DRIVER_REGISTRY_KEYS = [
    r"SYSTEM\CurrentControlSet\Services",
    r"SYSTEM\CurrentControlSet\Control\Class",
]

# Known-safe driver publisher patterns (case-insensitive substrings)
TRUSTED_PUBLISHERS = {
    "microsoft", "intel", "amd", "nvidia", "realtek",
    "broadcom", "qualcomm", "logitech", "dell", "hp",
    "lenovo", "asus", "samsung", "seagate", "western digital",
    "apple", "vmware", "oracle",
}


class DriverInfo:
    def __init__(self, name: str, description: str, inf_name: str,
                 signer: str, driver_date: str):
        self.name        = name
        self.description = description
        self.inf_name    = inf_name
        self.signer      = signer
        self.driver_date = driver_date
        self.detected_at = datetime.now()

    @property
    def is_signed(self) -> bool:
        return bool(self.signer) and self.signer.lower() != "not signed"

    @property
    def is_trusted_publisher(self) -> bool:
        if not self.signer:
            return False
        sl = self.signer.lower()
        return any(pub in sl for pub in TRUSTED_PUBLISHERS)


class DriverMonitor:
    """
    Polls Win32_PnPSignedDriver for newly installed drivers and
    alerts when an unsigned or untrusted driver appears.
    """

    POLL_INTERVAL = 10   # seconds

    def __init__(self, logger):
        self._log     = logger
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Baseline of known driver names when the tool starts
        self._known_drivers: Set[str] = set()
        self._lock = threading.Lock()

        # Callbacks
        self.on_new_driver: Optional[Callable[[DriverInfo], None]] = None

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        # Seed baseline
        self._known_drivers = self._get_current_driver_names()
        self._thread = threading.Thread(
            target=self._poll_loop, daemon=True, name="DriverMonitor"
        )
        self._thread.start()
        self._log.info("DriverMonitor", "Driver monitor started",
                       f"Baseline: {len(self._known_drivers)} drivers known")

    def stop(self) -> None:
        self._running = False

    def _poll_loop(self) -> None:
        while self._running:
            time.sleep(self.POLL_INTERVAL)
            try:
                current = self._get_current_drivers()
                with self._lock:
                    known = set(self._known_drivers)

                for drv in current:
                    key = drv.name
                    if key not in known:
                        self._on_new_driver(drv)
                        with self._lock:
                            self._known_drivers.add(key)
            except Exception as exc:
                self._log.medium("DriverMonitor", "Poll error", str(exc))

    def _on_new_driver(self, drv: DriverInfo) -> None:
        if not drv.is_signed:
            self._log.critical(
                "DriverMonitor",
                "UNSIGNED driver installed",
                f"'{drv.description}' ({drv.name}) — UNSIGNED driver detected. "
                "Unsigned drivers can hide malware at kernel level.",
            )
        elif not drv.is_trusted_publisher:
            self._log.high(
                "DriverMonitor",
                "New driver from untrusted publisher",
                f"'{drv.description}' signed by: '{drv.signer}' — "
                "Verify this driver is expected and legitimate.",
            )
        else:
            self._log.low(
                "DriverMonitor",
                "New driver installed",
                f"'{drv.description}' by '{drv.signer}' — appears legitimate",
            )

        if self.on_new_driver:
            self.on_new_driver(drv)

    def _get_current_drivers(self) -> List[DriverInfo]:
        drivers = []
        if not _WMI:
            return drivers
        try:
            pythoncom.CoInitialize()
            c = wmi.WMI()
            for d in c.Win32_PnPSignedDriver():
                drv = DriverInfo(
                    name        = getattr(d, "DeviceName", "") or "",
                    description = getattr(d, "DeviceName", "") or "",
                    inf_name    = getattr(d, "InfName", "") or "",
                    signer      = getattr(d, "Signer", "") or "",
                    driver_date = str(getattr(d, "DriverDate", "") or ""),
                )
                drivers.append(drv)
        except Exception:
            pass
        finally:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass
        return drivers

    def _get_current_driver_names(self) -> Set[str]:
        return {d.name for d in self._get_current_drivers()}


# ===========================================================================
# NetworkGuard
# ===========================================================================

# USB network adapter name/description patterns (case-insensitive)
ROGUE_ADAPTER_PATTERNS = [
    "rndis",              # Remote NDIS — common USB-to-Ethernet emulation
    "usb ethernet",
    "usb network",
    "cdc ether",          # CDC Ethernet Control Model
    "cdc ncm",            # Network Control Model
    "cdc ecm",
    "linux usb ethernet",
    "android usb",
    "gadget ethernet",
    "usb 10/100",
    "usb to lan",
    "asix",               # Common USB NIC chip used in attack tools
    "hak5",
    "bash bunny",
    "lan turtle",
    "shark jack",
]


class NetworkAdapterInfo:
    def __init__(self, name: str, mac: str, addrs: list):
        self.name        = name
        self.mac         = mac
        self.addrs       = addrs
        self.detected_at = datetime.now()

    @property
    def looks_rogue(self) -> bool:
        nl = self.name.lower()
        return any(p in nl for p in ROGUE_ADAPTER_PATTERNS)


class NetworkGuard:
    """
    Periodically scans network adapters and alerts when a new
    USB-style (RNDIS/CDC) network interface appears.
    """

    POLL_INTERVAL = 5   # seconds

    def __init__(self, logger):
        self._log     = logger
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Baseline: adapter names present at start
        self._known_adapters: Set[str] = set()
        self._lock = threading.Lock()

        # Callbacks
        self.on_rogue_adapter: Optional[Callable[[NetworkAdapterInfo], None]] = None

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._known_adapters = self._get_adapter_names()
        self._thread = threading.Thread(
            target=self._poll_loop, daemon=True, name="NetworkGuard"
        )
        self._thread.start()
        self._log.info(
            "NetworkGuard", "Network guard started",
            f"Baseline: {len(self._known_adapters)} adapters",
        )

    def stop(self) -> None:
        self._running = False

    def _poll_loop(self) -> None:
        while self._running:
            time.sleep(self.POLL_INTERVAL)
            try:
                current = self._get_adapters()
                current_names = {a.name for a in current}

                with self._lock:
                    known = set(self._known_adapters)

                # Fire callback for every adapter not seen before
                for adapter in current:
                    if adapter.name not in known:
                        self._on_new_adapter(adapter)

                # Sync known set to exactly what is currently present.
                # This correctly prunes disappeared adapters AND adds new ones,
                # without the old &= (current | known) bug that kept stale entries.
                with self._lock:
                    self._known_adapters = current_names

            except Exception as exc:
                self._log.medium("NetworkGuard", "Poll error", str(exc))

    def _on_new_adapter(self, adapter: NetworkAdapterInfo) -> None:
        if adapter.looks_rogue:
            self._log.critical(
                "NetworkGuard",
                "ROGUE USB Network Adapter Detected",
                f"Adapter '{adapter.name}' (MAC: {adapter.mac}) matches known "
                "USB attack tool patterns (RNDIS/CDC-Ethernet). "
                "This device may intercept traffic or provide backdoor access.",
            )
        else:
            self._log.high(
                "NetworkGuard",
                "New unknown network adapter appeared",
                f"Adapter '{adapter.name}' (MAC: {adapter.mac}) — "
                "Verify this is an expected USB device.",
            )

        if self.on_rogue_adapter and adapter.looks_rogue:
            self.on_rogue_adapter(adapter)

        # Attempt to disable rogue adapter via netsh
        if adapter.looks_rogue:
            self._disable_adapter(adapter.name)

    def _disable_adapter(self, name: str) -> None:
        try:
            result = subprocess.run(
                ["netsh", "interface", "set", "interface", name, "disabled"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                self._log.high(
                    "NetworkGuard",
                    f"Rogue adapter DISABLED: {name}",
                    "Netsh interface disabled successfully",
                )
            else:
                self._log.medium(
                    "NetworkGuard",
                    "Could not disable adapter",
                    f"netsh returned: {result.stderr.strip()[:200]}",
                )
        except Exception as exc:
            self._log.medium("NetworkGuard", "Disable error", str(exc))

    def _get_adapters(self) -> List[NetworkAdapterInfo]:
        adapters = []
        if not _PSUTIL:
            return adapters
        # Resolve AF_LINK once — value 17 is the Linux/fallback raw-socket family
        # number for hardware addresses (same as socket.AF_PACKET on Linux).
        # On Windows psutil exposes AF_LINK; on Linux/macOS it may be absent.
        _AF_LINK = getattr(psutil, "AF_LINK", 17)
        try:
            if_addrs = psutil.net_if_addrs()
            for name, addrs in if_addrs.items():
                mac = ""
                ip_list = []
                for addr in addrs:
                    if addr.family == _AF_LINK:   # MAC / hardware address
                        mac = addr.address
                    else:
                        ip_list.append(addr.address)
                adapters.append(NetworkAdapterInfo(name, mac, ip_list))
        except Exception:
            pass
        return adapters

    def _get_adapter_names(self) -> Set[str]:
        return {a.name for a in self._get_adapters()}
