"""
USBShield - Settings Manager
============================
Loads and saves all application settings to config/settings.json.
Every write is immediate — no "Apply" button needed.
Provides rollback tracking so disabling a feature restores the
original system state (registry, USB storage policy, etc.).
"""

import json
import os
import threading
from typing import Any, Callable, Dict, List, Optional


DEFAULTS = {
    "protection": {
        "hid_injection_detection":      True,
        "device_whitelist_enforcement": True,
        "usb_storage_scanning":         True,
        "autorun_blocking":             True,
        "driver_monitoring":            True,
        "network_guard":                True,
        "data_exfiltration_detection":  True,
    },
    "hid_detector": {
        "warning_kps":        25,
        "injection_kps":      60,
        "variance_threshold": 8.0,
        "alert_cooldown_sec": 5,
        "burst_count":        10,
        "burst_ms":           150,
    },
    "storage_guard": {
        "auto_delete_autorun":      True,
        "exfil_volume_mb":          100,
        "exfil_window_seconds":     60,
        "exfil_file_count":         50,
        "max_scan_files_per_drive": 5000,
        "drive_alert_cooldown_sec": 60,
    },
    "device_monitor": {
        "auto_block_known_attack_devices": True,
        "auto_block_unknown_devices":      False,
        "poll_interval_sec":               1,
    },
    "alerts": {
        "full_screen_alert":                  True,
        "alert_sound":                        True,
        "medium_auto_dismiss_sec":            30,
        "high_auto_dismiss_sec":              60,
        "critical_requires_manual_dismiss":   True,
    },
    "hardening": {
        "autorun_blocked":   False,
        "storage_blocked":   False,
        "hardening_applied": False,
    },
    "network_guard": {
        "auto_disable_rogue_adapters": True,
        "poll_interval_sec":           5,
    },
    "driver_monitor": {
        "alert_on_unsigned_drivers":  True,
        "alert_on_unknown_publisher": True,
        "poll_interval_sec":          10,
    },
    "logging": {
        "log_dir":           "logs",
        "max_memory_events": 2000,
    },
}


class SettingsManager:
    """
    Thread-safe persistent settings store.

    Usage::

        sm = SettingsManager()
        sm.get('protection', 'hid_injection_detection')   # True
        sm.set('protection', 'hid_injection_detection', False)  # saves immediately
        sm.register_callback('protection.hid_injection_detection', fn)
    """

    def __init__(self, path: str = "config/settings.json"):
        self._path = path
        self._lock = threading.RLock()
        self._callbacks: Dict[str, List[Callable]] = {}
        self._data = self._load()

    # ------------------------------------------------------------------
    # Load / Save
    # ------------------------------------------------------------------

    def _load(self) -> dict:
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            # Deep-merge loaded values over defaults
            return self._merge(DEFAULTS, loaded)
        except (FileNotFoundError, json.JSONDecodeError):
            return self._deep_copy(DEFAULTS)

    def _save(self) -> None:
        os.makedirs(os.path.dirname(self._path), exist_ok=True)
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)

    @staticmethod
    def _deep_copy(d: dict) -> dict:
        return json.loads(json.dumps(d))

    @staticmethod
    def _merge(base: dict, override: dict) -> dict:
        result = json.loads(json.dumps(base))
        for k, v in override.items():
            if k in result and isinstance(result[k], dict) and isinstance(v, dict):
                result[k] = SettingsManager._merge(result[k], v)
            else:
                result[k] = v
        return result

    # ------------------------------------------------------------------
    # Get / Set
    # ------------------------------------------------------------------

    def get(self, *keys, default: Any = None) -> Any:
        with self._lock:
            d = self._data
            for k in keys:
                if not isinstance(d, dict):
                    return default
                d = d.get(k, default)
                if d is default:
                    return default
            return d

    def set(self, *keys_and_value) -> None:
        """set('section', 'key', value)  — saves immediately, fires callbacks."""
        if len(keys_and_value) < 2:
            return
        *keys, value = keys_and_value
        dot_key = ".".join(str(k) for k in keys)

        with self._lock:
            d = self._data
            for k in keys[:-1]:
                if k not in d or not isinstance(d[k], dict):
                    d[k] = {}
                d = d[k]
            d[keys[-1]] = value
            self._save()
            cbs = list(self._callbacks.get(dot_key, []))

        for cb in cbs:
            try:
                cb(value)
            except Exception:
                pass

    def get_section(self, section: str) -> dict:
        with self._lock:
            return dict(self._data.get(section, {}))

    def all(self) -> dict:
        with self._lock:
            return self._deep_copy(self._data)

    # ------------------------------------------------------------------
    # Change callbacks
    # ------------------------------------------------------------------

    def register_callback(self, dot_key: str, fn: Callable) -> None:
        """dot_key e.g. 'protection.hid_injection_detection'"""
        with self._lock:
            self._callbacks.setdefault(dot_key, []).append(fn)

    def unregister_callback(self, dot_key: str, fn: Callable) -> None:
        with self._lock:
            cbs = self._callbacks.get(dot_key, [])
            self._callbacks[dot_key] = [c for c in cbs if c is not fn]
