"""
USBShield — Main Entry Point  (v2 — all 8 issues fixed)
=========================================================
FIXED IN THIS VERSION:
  1. SettingsManager wired in — all settings load from JSON on startup
  2. Event extras carry full device info (vid/pid/device_name/instance_id)
  3. File-scan events tagged is_file_scan=True — no alert spam
  4. Device counter uses session_total from DeviceMonitor (not WMI-dependent)
  5. Block/Allow/Dismiss are distinct — block uses instance_id from extras
  6. enumerate_current_devices() called at start — device panel pre-populated
  7. Whitelist handler uses event.extra — works even after device disconnects
  8. HID hook fixed (NULL hMod + burst detection) — catches Rubber Ducky

ROLLBACK: Turning OFF any feature in Settings immediately restores
          the original system state (registry, USB storage policy, etc.)
"""

import json
import os
import subprocess
import sys
import threading
import time
from typing import Optional

os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.threat_logger import Severity, ThreatLogger


# ---------------------------------------------------------------------------
# Admin elevation
# ---------------------------------------------------------------------------

def is_admin() -> bool:
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin() -> None:
    try:
        import ctypes
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable,
            " ".join(f'"{a}"' for a in sys.argv), None, 1,
        )
    except Exception as exc:
        print(f"[USBShield] Elevation failed: {exc}")
    sys.exit(0)


# ---------------------------------------------------------------------------
# USBShieldApp
# ---------------------------------------------------------------------------

class USBShieldApp:
    """Orchestrates all protection modules."""

    def __init__(self):
        # ── Settings (must be first — everything reads from it) ──────────
        from core.settings_manager import SettingsManager
        self.settings = SettingsManager("config/settings.json")

        # ── Logger ───────────────────────────────────────────────────────
        log_cfg = self.settings.get_section("logging")
        self.logger = ThreatLogger(log_dir=log_cfg.get("log_dir", "logs"))
        self.logger.info("System", "USBShield v2 starting",
                         f"Python {sys.version.split()[0]} | {sys.platform}")

        # ── Core modules ─────────────────────────────────────────────────
        from core.whitelist_manager  import WhitelistManager
        from core.device_monitor     import DeviceMonitor
        from core.hid_detector       import HIDInjectionDetector
        from core.file_scanner       import FileScanner
        from core.storage_guard      import StorageGuard
        from core.system_hardener    import SystemHardener
        from core.driver_network_monitor import DriverMonitor, NetworkGuard

        self.whitelist      = WhitelistManager()
        self.device_monitor = DeviceMonitor(self.whitelist, self.logger)
        self.hid_detector   = HIDInjectionDetector(self.logger)
        self.file_scanner   = FileScanner(self.logger)
        self.storage_guard  = StorageGuard(self.file_scanner, self.logger)
        self.hardener       = SystemHardener(self.logger)
        self.driver_monitor = DriverMonitor(self.logger)
        self.network_guard  = NetworkGuard(self.logger)

        # Apply saved settings to modules
        dm_cfg = self.settings.get_section("device_monitor")
        self.device_monitor.auto_block_known_attack_devices = dm_cfg.get(
            "auto_block_known_attack_devices", True)
        self.device_monitor.auto_block_unknown = dm_cfg.get(
            "auto_block_unknown_devices", False)

        sg_cfg = self.settings.get_section("storage_guard")
        self.storage_guard.auto_delete_autorun  = sg_cfg.get("auto_delete_autorun", True)
        self.storage_guard.drive_alert_cooldown = sg_cfg.get("drive_alert_cooldown_sec", 60)

        self._wire_callbacks()
        self._running = False

    # ------------------------------------------------------------------
    # Callback wiring
    # ------------------------------------------------------------------

    def _wire_callbacks(self) -> None:
        self.device_monitor.on_device_connected    = self._on_device_connected
        self.device_monitor.on_device_disconnected = self._on_device_disconnected
        self.hid_detector.on_injection_detected    = self._on_hid_injection
        self.storage_guard.on_new_drive            = self._on_new_drive
        self.storage_guard.on_exfiltration         = self._on_exfiltration
        self.storage_guard.on_sensitive_copy       = self._on_sensitive_copy
        self.storage_guard.on_file_threat          = self._on_file_threat
        self.driver_monitor.on_new_driver          = self._on_new_driver
        self.network_guard.on_rogue_adapter        = self._on_rogue_adapter

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        prot = self.settings.get_section("protection")

        # Always apply autorun block at startup (safe default)
        self.hardener.disable_autorun()

        # Restore previously saved hardening state
        hard = self.settings.get_section("hardening")
        if hard.get("hardening_applied"):
            self.hardener.apply_all()
        if hard.get("storage_blocked"):
            self.hardener.block_usb_storage()

        if prot.get("hid_injection_detection", True):
            self.hid_detector.start()
        if prot.get("device_whitelist_enforcement", True):
            self.device_monitor.start()
        if prot.get("usb_storage_scanning", True):
            self.storage_guard.start()
        if prot.get("driver_monitoring", True):
            self.driver_monitor.start()
        if prot.get("network_guard", True):
            self.network_guard.start()

        self.logger.info("System", "All protection modules active",
                         "USBShield is fully operational")

    def stop(self) -> None:
        self._running = False
        for mod in (self.hid_detector, self.device_monitor,
                    self.storage_guard, self.driver_monitor, self.network_guard):
            try:
                mod.stop()
            except Exception:
                pass
        self.logger.info("System", "USBShield stopped", "All modules shut down")

    # ------------------------------------------------------------------
    # Event callbacks
    # ------------------------------------------------------------------

    def _on_device_connected(self, dev, risk: str, reason: str) -> None:
        # Extra context already embedded in the log event by DeviceMonitor v2.
        # Log an additional warning for unknown HID devices.
        if dev.is_hid_class and risk in ("HIGH", "CRITICAL"):
            self.logger.high(
                "DeviceMonitor",
                "Unknown HID device — injection watch elevated",
                f"Monitoring all keystrokes closely — {dev.name} [{dev.vid}:{dev.pid}]",
                device_id=dev.instance_id,
                extra={
                    "vid":         dev.vid,
                    "pid":         dev.pid,
                    "device_name": dev.name,
                    "instance_id": dev.instance_id,
                    "blocked":     dev.is_blocked,
                    "risk":        risk,
                },
            )

    def _on_device_disconnected(self, dev) -> None:
        pass

    def _on_hid_injection(self, injection_event) -> None:
        # Event already logged inside HIDInjectionDetector with full extras.
        pass

    def _on_new_drive(self, drive: str, threats) -> None:
        # StorageGuard v2 fires ONE summary log event per drive.
        # Nothing extra needed here.
        pass

    def _on_exfiltration(self, drive: str, mb: float, count: int) -> None:
        pass   # Already logged in StorageGuard with is_drive_summary=True

    def _on_sensitive_copy(self, drive: str, path: str) -> None:
        pass   # Already logged in StorageGuard

    def _on_file_threat(self, drive: str, threat) -> None:
        # StorageGuard v2 already logs individual file threats with
        # is_file_scan=True so they never trigger a full-screen alert.
        # This callback is kept for any future custom handling.
        pass

    def _on_new_driver(self, driver_info) -> None:
        if not driver_info.is_signed:
            self.logger.critical(
                "DriverMonitor",
                "Unsigned USB Driver Installed — Possible Rootkit",
                f"Driver '{driver_info.description}' has NO digital signature.",
                extra={"driver_name": driver_info.name,
                       "inf": driver_info.inf_name,
                       "is_drive_summary": True},
            )

    def _on_rogue_adapter(self, adapter) -> None:
        self.logger.critical(
            "NetworkGuard",
            "Rogue USB Network Adapter Detected",
            f"'{adapter.name}' (MAC {adapter.mac}) matches USB attack tool patterns.",
            extra={"adapter_name": adapter.name,
                   "mac": adapter.mac,
                   "is_drive_summary": True},
        )


# ---------------------------------------------------------------------------
# Demo injector (non-Windows / --demo mode)
# ---------------------------------------------------------------------------

class DemoThreatInjector:
    DEMO_EVENTS = [
        ("HIDDetector",   "CRITICAL",
         "HID Keystroke Injection — BURST DETECTED",
         "10 keys in 48ms (burst mode) — 100% confidence",
         {"kps": 208, "confidence": 100, "burst_mode": True,
          "burst_count": 10, "burst_ms": 48}),

        ("DeviceMonitor", "CRITICAL",
         "USB device connected — CRITICAL",
         "Hak5 Rubber Ducky [F000:0002]  KNOWN ATTACK DEVICE",
         {"vid": "F000", "pid": "0002",
          "device_name": "Hak5 Rubber Ducky",
          "instance_id": "USB\\VID_F000&PID_0002\\DEMO",
          "blocked": True, "risk": "CRITICAL"}),

        ("StorageGuard",  "CRITICAL",
         "Data Exfiltration Detected",
         "142.3 MB / 67 files copied to E:\\ in 60 s",
         {"drive": "E:\\", "mb": 142.3,
          "file_count": 67, "is_drive_summary": True}),

        ("StorageGuard",  "HIGH",
         "USB Drive E:\\ — 3 threat(s) detected",
         "Scan found: ScriptHeuristic: payload.ps1, HighEntropy: ransom.exe, Autorun: autorun.inf",
         {"drive": "E:\\", "threat_count": 3,
          "is_drive_summary": True}),

        ("NetworkGuard",  "CRITICAL",
         "Rogue USB Network Adapter Detected",
         "'RNDIS Gadget' (MAC 02:00:DE:AD:BE:EF) — possible MITM",
         {"adapter_name": "RNDIS Gadget",
          "mac": "02:00:DE:AD:BE:EF",
          "is_drive_summary": True}),

        ("DriverMonitor", "CRITICAL",
         "Unsigned USB Driver Installed — Possible Rootkit",
         "Driver 'BadUSB HID Device' has NO digital signature.",
         {"driver_name": "BadUSB HID Device",
          "is_drive_summary": True}),

        ("StorageGuard",  "HIGH",
         "Sensitive File Copied to USB",
         "'id_rsa' written to F:\\ — possible credential theft",
         {"drive": "F:\\", "is_drive_summary": True}),

        # Individual file threats — tagged is_file_scan so NO full-screen alert
        ("FileScanner",   "HIGH",
         "Threat: payload.ps1",
         "PowerShell IEX — executing remote payload",
         {"drive": "E:\\", "is_file_scan": True,
          "category": "ScriptHeuristic"}),

        ("FileScanner",   "HIGH",
         "Threat: ransom.exe",
         "High entropy (7.91 bits) — packed/encrypted payload",
         {"drive": "E:\\", "is_file_scan": True,
          "entropy": 7.91, "category": "HighEntropy"}),
    ]

    def __init__(self, app: USBShieldApp):
        self._app     = app
        self._idx     = 0
        self._thread: Optional[threading.Thread] = None
        self._running = False

    def start(self, interval: float = 7.0) -> None:
        self._running  = True
        self._interval = interval
        self._thread   = threading.Thread(
            target=self._loop, daemon=True, name="DemoInjector"
        )
        self._thread.start()

    def stop(self) -> None:
        self._running = False

    def _loop(self) -> None:
        time.sleep(2)
        while self._running:
            cat, sev, title, desc, extra = (
                self.DEMO_EVENTS[self._idx % len(self.DEMO_EVENTS)]
            )
            self._app.logger.log(cat, Severity[sev], title, desc, extra=extra)
            self._idx += 1
            time.sleep(self._interval)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    if sys.platform == "win32" and not is_admin():
        print("[USBShield] Requesting Administrator elevation…")
        relaunch_as_admin()
        return

    app  = USBShieldApp()
    demo = None

    if sys.platform != "win32" or "--demo" in sys.argv:
        app.logger.info("System", "DEMO MODE",
                        "Synthetic threats injected every 7 s to demonstrate all features.")
        demo = DemoThreatInjector(app)

    app.start()
    if demo:
        demo.start()

    from gui.main_window import MainWindow
    window = MainWindow(app)
    try:
        window.run()
    except KeyboardInterrupt:
        pass
    finally:
        app.stop()
        if demo:
            demo.stop()


if __name__ == "__main__":
    main()
