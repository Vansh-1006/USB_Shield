#!/usr/bin/env bash
# USBShield Demo Launcher (Linux/macOS — for testing the GUI and alert system)
# Runs in demo mode: synthetic threat events injected every 6 seconds
cd "$(dirname "$0")"
python3 main.py --demo "$@"
